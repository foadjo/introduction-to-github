import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { userService } from '../../services/api';

const Customers = () => {
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [pointsToAdd, setPointsToAdd] = useState('');
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  const queryClient = useQueryClient();

  // Récupérer tous les clients
  const { data: customers, isLoading, isError, error } = useQuery({
    queryKey: ['customers'],
    queryFn: () => userService.getAll({ role: 'client' }),
    // Données fictives pour le développement
    placeholderData: [
      {
        id: 1,
        first_name: 'Jean',
        last_name: 'Dupont',
        email: 'jean.dupont@example.com',
        phone: '0612345678',
        created_at: '2025-05-15T10:30:00',
        loyalty_card: {
          id: 1,
          card_number: 'SNACK00001',
          qr_code: 'SNACK-1-20250607',
          points: 120,
          created_at: '2025-05-15T10:30:00'
        }
      },
      {
        id: 2,
        first_name: 'Marie',
        last_name: 'Martin',
        email: 'marie.martin@example.com',
        phone: '0687654321',
        created_at: '2025-05-20T14:15:00',
        loyalty_card: {
          id: 2,
          card_number: 'SNACK00002',
          qr_code: 'SNACK-2-20250607',
          points: 85,
          created_at: '2025-05-20T14:15:00'
        }
      },
      {
        id: 3,
        first_name: 'Pierre',
        last_name: 'Durand',
        email: 'pierre.durand@example.com',
        phone: '0698765432',
        created_at: '2025-06-01T09:45:00',
        loyalty_card: null
      }
    ]
  });

  // Mutation pour créer une carte de fidélité
  const createCardMutation = useMutation({
    mutationFn: (userId) => userService.createLoyaltyCard(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setMessage('Carte de fidélité créée avec succès !');
      setMessageType('success');
    },
    onError: (error) => {
      setMessage(error.message || 'Erreur lors de la création de la carte');
      setMessageType('error');
    }
  });

  // Mutation pour mettre à jour les points
  const updatePointsMutation = useMutation({
    mutationFn: ({ userId, points }) => userService.updateLoyaltyPoints(userId, points),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setMessage('Points mis à jour avec succès !');
      setMessageType('success');
      closeModal();
    },
    onError: (error) => {
      setMessage(error.message || 'Erreur lors de la mise à jour des points');
      setMessageType('error');
    }
  });

  // Ouvrir le modal pour modifier les points
  const openPointsModal = (customer) => {
    setSelectedCustomer(customer);
    setPointsToAdd('');
    setIsModalOpen(true);
  };

  // Fermer le modal
  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedCustomer(null);
    setPointsToAdd('');
  };

  // Créer une carte de fidélité
  const handleCreateCard = (customer) => {
    if (window.confirm(`Créer une carte de fidélité pour ${customer.first_name} ${customer.last_name} ?`)) {
      createCardMutation.mutate(customer.id);
    }
  };

  // Mettre à jour les points
  const handleUpdatePoints = (e) => {
    e.preventDefault();
    
    if (!pointsToAdd || isNaN(parseInt(pointsToAdd))) {
      setMessage('Veuillez saisir un nombre de points valide');
      setMessageType('error');
      return;
    }

    const newPoints = parseInt(pointsToAdd);
    updatePointsMutation.mutate({ 
      userId: selectedCustomer.id, 
      points: newPoints 
    });
  };

  // Fermer le message
  const closeMessage = () => {
    setMessage('');
    setMessageType('');
  };

  // Formater la date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Gestion des clients</h1>
          <p className="text-gray-600 mt-2">Gérez vos clients et leurs cartes de fidélité</p>
        </div>

        {/* Message de statut */}
        {message && (
          <div className={`mb-8 border-l-4 p-4 relative ${
            messageType === 'success' 
              ? 'bg-green-100 border-green-500' 
              : 'bg-red-100 border-red-500'
          }`}>
            <p className={messageType === 'success' ? 'text-green-700' : 'text-red-700'}>
              {message}
            </p>
            <button
              onClick={closeMessage}
              className={`absolute top-2 right-2 hover:opacity-75 ${
                messageType === 'success' ? 'text-green-700' : 'text-red-700'
              }`}
              aria-label="Fermer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        )}

        {/* Statistiques rapides */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-100 rounded-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total clients</p>
                <p className="text-2xl font-bold text-gray-900">{customers?.length || 0}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-green-100 rounded-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Avec carte fidélité</p>
                <p className="text-2xl font-bold text-gray-900">
                  {customers?.filter(c => c.loyalty_card).length || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-orange-100 rounded-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Points moyens</p>
                <p className="text-2xl font-bold text-gray-900">
                  {customers?.filter(c => c.loyalty_card).length > 0
                    ? Math.round(
                        customers
                          .filter(c => c.loyalty_card)
                          .reduce((sum, c) => sum + c.loyalty_card.points, 0) /
                        customers.filter(c => c.loyalty_card).length
                      )
                    : 0
                  }
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Liste des clients */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-orange-500 border-r-transparent"></div>
            <p className="mt-4 text-gray-600">Chargement des clients...</p>
          </div>
        ) : isError ? (
          <div className="bg-red-50 border-l-4 border-red-500 p-4">
            <p className="text-red-700">{error?.message || 'Erreur lors du chargement des clients'}</p>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Client
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Contact
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Carte fidélité
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Points
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Inscription
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {customers?.map((customer) => (
                    <tr key={customer.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center">
                              <span className="text-sm font-medium text-orange-600">
                                {customer.first_name.charAt(0)}{customer.last_name.charAt(0)}
                              </span>
                            </div>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {customer.first_name} {customer.last_name}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{customer.email}</div>
                        <div className="text-sm text-gray-500">{customer.phone}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {customer.loyalty_card ? (
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {customer.loyalty_card.card_number}
                            </div>
                            <div className="text-sm text-gray-500">
                              {customer.loyalty_card.qr_code}
                            </div>
                          </div>
                        ) : (
                          <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                            Aucune carte
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {customer.loyalty_card ? (
                          <span className="text-sm font-bold text-orange-600">
                            {customer.loyalty_card.points} pts
                          </span>
                        ) : (
                          <span className="text-sm text-gray-500">-</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(customer.created_at)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {customer.loyalty_card ? (
                          <button
                            onClick={() => openPointsModal(customer)}
                            className="text-orange-600 hover:text-orange-900"
                          >
                            Modifier points
                          </button>
                        ) : (
                          <button
                            onClick={() => handleCreateCard(customer)}
                            disabled={createCardMutation.isPending}
                            className="text-green-600 hover:text-green-900 disabled:text-green-300"
                          >
                            {createCardMutation.isPending ? 'Création...' : 'Créer carte'}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Modal de modification des points */}
        {isModalOpen && selectedCustomer && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Modifier les points de {selectedCustomer.first_name} {selectedCustomer.last_name}
              </h3>
              
              <div className="mb-4">
                <p className="text-sm text-gray-600">
                  Points actuels : <span className="font-semibold text-orange-600">
                    {selectedCustomer.loyalty_card?.points || 0} points
                  </span>
                </p>
              </div>

              <form onSubmit={handleUpdatePoints} className="space-y-4">
                <div>
                  <label htmlFor="points" className="block text-sm font-medium text-gray-700 mb-1">
                    Nouveaux points
                  </label>
                  <input
                    type="number"
                    id="points"
                    value={pointsToAdd}
                    onChange={(e) => setPointsToAdd(e.target.value)}
                    min="0"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Entrez le nouveau nombre de points"
                  />
                </div>

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={updatePointsMutation.isPending}
                    className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 disabled:bg-orange-300"
                  >
                    {updatePointsMutation.isPending ? 'Mise à jour...' : 'Mettre à jour'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Customers;

