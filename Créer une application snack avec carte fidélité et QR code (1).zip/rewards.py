"""
Routes de gestion des récompenses pour l'application
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.main import db
from src.models.user import User
from src.models.reward import Reward, UsedReward

rewards_bp = Blueprint('rewards', __name__)

# Fonction utilitaire pour vérifier si l'utilisateur est admin
def is_admin(user_id):
    """Vérifier si l'utilisateur est un administrateur"""
    user = User.query.get(user_id)
    return user and user.role == 'admin'


@rewards_bp.route('', methods=['GET'])
def get_rewards():
    """Récupérer toutes les récompenses disponibles"""
    # Paramètre pour filtrer les récompenses actives uniquement
    active_only = request.args.get('active', 'false').lower() == 'true'
    
    # Construire la requête
    query = Reward.query
    
    if active_only:
        query = query.filter_by(is_active=True)
    
    # Exécuter la requête
    rewards = query.all()
    
    return jsonify([reward.to_dict() for reward in rewards]), 200


@rewards_bp.route('/<int:reward_id>', methods=['GET'])
def get_reward(reward_id):
    """Récupérer une récompense par son ID"""
    reward = Reward.query.get(reward_id)
    
    if not reward:
        return jsonify({'message': 'Récompense non trouvée'}), 404
    
    return jsonify(reward.to_dict()), 200


@rewards_bp.route('', methods=['POST'])
@jwt_required()
def create_reward():
    """Créer une nouvelle récompense (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    data = request.get_json()
    
    # Vérifier les données requises
    required_fields = ['name', 'points_required']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Le champ {field} est requis'}), 400
    
    # Créer une nouvelle récompense
    reward = Reward(
        name=data['name'],
        description=data.get('description', ''),
        points_required=int(data['points_required']),
        is_active=data.get('is_active', True)
    )
    
    db.session.add(reward)
    db.session.commit()
    
    return jsonify(reward.to_dict()), 201


@rewards_bp.route('/<int:reward_id>', methods=['PUT'])
@jwt_required()
def update_reward(reward_id):
    """Mettre à jour une récompense (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    reward = Reward.query.get(reward_id)
    
    if not reward:
        return jsonify({'message': 'Récompense non trouvée'}), 404
    
    data = request.get_json()
    
    # Mettre à jour les champs de la récompense
    if 'name' in data:
        reward.name = data['name']
    if 'description' in data:
        reward.description = data['description']
    if 'points_required' in data:
        reward.points_required = int(data['points_required'])
    if 'is_active' in data:
        reward.is_active = data['is_active']
    
    db.session.commit()
    
    return jsonify(reward.to_dict()), 200


@rewards_bp.route('/<int:reward_id>', methods=['DELETE'])
@jwt_required()
def delete_reward(reward_id):
    """Supprimer une récompense (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    reward = Reward.query.get(reward_id)
    
    if not reward:
        return jsonify({'message': 'Récompense non trouvée'}), 404
    
    # Vérifier si la récompense a déjà été utilisée
    if UsedReward.query.filter_by(reward_id=reward_id).first():
        # Au lieu de supprimer, désactiver la récompense
        reward.is_active = False
        db.session.commit()
        return jsonify({'message': 'Récompense désactivée car déjà utilisée'}), 200
    
    db.session.delete(reward)
    db.session.commit()
    
    return jsonify({'message': 'Récompense supprimée avec succès'}), 200


@rewards_bp.route('/redeem/<int:reward_id>', methods=['POST'])
@jwt_required()
def redeem_reward(reward_id):
    """Échanger des points contre une récompense"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    # Vérifier si l'utilisateur a une carte de fidélité
    if not user.loyalty_card:
        return jsonify({'message': 'Vous n\'avez pas de carte de fidélité'}), 400
    
    # Récupérer la récompense
    reward = Reward.query.get(reward_id)
    
    if not reward:
        return jsonify({'message': 'Récompense non trouvée'}), 404
    
    if not reward.is_active:
        return jsonify({'message': 'Cette récompense n\'est plus disponible'}), 400
    
    # Vérifier si l'utilisateur a assez de points
    if user.loyalty_card.points < reward.points_required:
        return jsonify({
            'message': 'Points insuffisants',
            'points_required': reward.points_required,
            'current_points': user.loyalty_card.points
        }), 400
    
    # Déduire les points
    user.loyalty_card.points -= reward.points_required
    
    # Enregistrer l'utilisation de la récompense
    used_reward = UsedReward(
        user_id=user_id,
        reward_id=reward_id
    )
    
    db.session.add(used_reward)
    db.session.commit()
    
    return jsonify({
        'message': 'Récompense échangée avec succès',
        'reward': reward.to_dict(),
        'remaining_points': user.loyalty_card.points
    }), 200


@rewards_bp.route('/history', methods=['GET'])
@jwt_required()
def get_reward_history():
    """Récupérer l'historique des récompenses utilisées par l'utilisateur"""
    user_id = get_jwt_identity()
    
    # Récupérer l'historique des récompenses utilisées
    used_rewards = UsedReward.query.filter_by(user_id=user_id).order_by(UsedReward.used_date.desc()).all()
    
    # Préparer la réponse avec les détails des récompenses
    result = []
    for used_reward in used_rewards:
        reward = Reward.query.get(used_reward.reward_id)
        if reward:
            result.append({
                'id': used_reward.id,
                'reward_id': reward.id,
                'reward_name': reward.name,
                'points_required': reward.points_required,
                'used_date': used_reward.used_date.isoformat() if used_reward.used_date else None
            })
    
    return jsonify(result), 200

