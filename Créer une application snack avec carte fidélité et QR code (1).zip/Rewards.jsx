import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { loyaltyService } from '../services/api';

const Rewards = () => {
  const [selectedReward, setSelectedReward] = useState(null);
  const [confirmationOpen, setConfirmationOpen] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const queryClient = useQueryClient();

  // Récupérer les points de fidélité
  const { data: loyaltyData, isLoading: isLoadingPoints } = useQuery({
    queryKey: ['loyaltyCard'],
    queryFn: loyaltyService.getCard,
    // Données fictives pour le développement
    placeholderData: {
      loyalty_card: { points: 120 }
    }
  });

  // Récupérer les récompenses disponibles
  const { data: rewards, isLoading: isLoadingRewards } = useQuery({
    queryKey: ['rewards'],
    queryFn: () => loyaltyService.getRewards({ active: true }),
    // Données fictives pour le développement
    placeholderData: [
      {
        id: 1,
        name: 'Boisson gratuite',
        description: 'Une boisson au choix offerte',
        points_required: 100,
        is_active: true
      },
      {
        id: 2,
        name: 'Sandwich gratuit',
        description: 'Un sandwich au choix offert',
        points_required: 200,
        is_active: true
      },
      {
        id: 3,
        name: 'Menu complet',
        description: 'Un menu complet offert (sandwich + boisson + dessert)',
        points_required: 500,
        is_active: true
      },
      {
        id: 4,
        name: 'Réduction de 10%',
        description: 'Une réduction de 10% sur votre prochain achat',
        points_required: 150,
        is_active: true
      },
      {
        id: 5,
        name: 'Dessert gratuit',
        description: 'Un dessert au choix offert',
        points_required: 80,
        is_active: true
      }
    ]
  });

  // Récupérer l'historique des récompenses utilisées
  const { data: rewardHistory, isLoading: isLoadingHistory } = useQuery({
    queryKey: ['rewardHistory'],
    queryFn: loyaltyService.getRewardHistory,
    // Données fictives pour le développement
    placeholderData: [
      {
        id: 1,
        reward_id: 1,
        reward_name: 'Boisson gratuite',
        used_date: '2025-06-01T18:45:00',
        points_required: 100
      },
      {
        id: 2,
        reward_id: 5,
        reward_name: 'Dessert gratuit',
        used_date: '2025-05-15T13:20:00',
        points_required: 80
      }
    ]
  });

  // Mutation pour échanger des points contre une récompense
  const redeemMutation = useMutation({
    mutationFn: (rewardId) => loyaltyService.redeemReward(rewardId),
    onSuccess: (data) => {
      setSuccessMessage(`Félicitations ! Vous avez échangé vos points contre "${selectedReward.name}".`);
      setConfirmationOpen(false);
      setSelectedReward(null);
      
      // Invalider les requêtes pour forcer un rafraîchissement des données
      queryClient.invalidateQueries({ queryKey: ['loyaltyCard'] });
      queryClient.invalidateQueries({ queryKey: ['rewardHistory'] });
    },
    onError: (error) => {
      setConfirmationOpen(false);
      setSuccessMessage(`Erreur: ${error.message || 'Impossible d\'échanger vos points. Veuillez réessayer.'}`);
    }
  });

  // Ouvrir la confirmation d'échange
  const openConfirmation = (reward) => {
    setSelectedReward(reward);
    setConfirmationOpen(true);
  };

  // Fermer la confirmation d'échange
  const closeConfirmation = () => {
    setConfirmationOpen(false);
    setSelectedReward(null);
  };

  // Échanger des points contre une récompense
  const handleRedeem = () => {
    if (!selectedReward) return;
    redeemMutation.mutate(selectedReward.id);
  };

  // Fermer le message de succès
  const closeSuccessMessage = () => {
    setSuccessMessage('');
  };

  // Formater la date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Mes Récompenses</h1>
          <p className="text-gray-600">
            Échangez vos points contre des récompenses exclusives
          </p>
        </div>

        {/* Message de succès */}
        {successMessage && (
          <div className="mb-8 bg-green-100 border-l-4 border-green-500 p-4 relative">
            <p className="text-green-700">{successMessage}</p>
            <button
              onClick={closeSuccessMessage}
              className="absolute top-2 right-2 text-green-700 hover:text-green-900"
              aria-label="Fermer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        )}

        {/* Points disponibles */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Points disponibles</h2>
            {isLoadingPoints ? (
              <div className="inline-block h-5 w-5 animate-spin rounded-full border-2 border-solid border-orange-500 border-r-transparent"></div>
            ) : (
              <span className="text-2xl font-bold text-orange-600">{loyaltyData?.loyalty_card?.points || 0}</span>
            )}
          </div>
        </div>

        {/* Récompenses disponibles */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="px-6 py-4 bg-orange-50 border-b border-orange-100">
            <h2 className="text-xl font-semibold text-gray-900">Récompenses disponibles</h2>
          </div>
          
          {isLoadingRewards ? (
            <div className="p-6 text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-orange-500 border-r-transparent"></div>
              <p className="mt-4 text-gray-600">Chargement des récompenses...</p>
            </div>
          ) : rewards && rewards.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
              {rewards.map((reward) => (
                <div key={reward.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{reward.name}</h3>
                    <span className="bg-orange-100 text-orange-800 text-xs font-semibold px-2.5 py-0.5 rounded">
                      {reward.points_required} points
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm mb-4">{reward.description}</p>
                  <button
                    onClick={() => openConfirmation(reward)}
                    disabled={!reward.is_active || (loyaltyData?.loyalty_card?.points || 0) < reward.points_required}
                    className={`w-full py-2 px-4 rounded-md text-sm font-medium ${
                      reward.is_active && (loyaltyData?.loyalty_card?.points || 0) >= reward.points_required
                        ? 'bg-orange-600 text-white hover:bg-orange-700'
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {!reward.is_active
                      ? 'Non disponible'
                      : (loyaltyData?.loyalty_card?.points || 0) < reward.points_required
                        ? `Pas assez de points (${reward.points_required - (loyaltyData?.loyalty_card?.points || 0)} manquants)`
                        : 'Échanger'}
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-center">
              <p className="text-gray-600">Aucune récompense disponible pour le moment.</p>
            </div>
          )}
        </div>

        {/* Historique des récompenses utilisées */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Historique des récompenses</h2>
          </div>
          
          {isLoadingHistory ? (
            <div className="p-6 text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-orange-500 border-r-transparent"></div>
              <p className="mt-4 text-gray-600">Chargement de l'historique...</p>
            </div>
          ) : rewardHistory && rewardHistory.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Récompense
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Points utilisés
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {rewardHistory.map((item) => (
                    <tr key={item.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(item.used_date)}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900">
                        {item.reward_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-right text-red-600">
                        -{item.points_required}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 text-center">
              <p className="text-gray-600">Vous n'avez pas encore utilisé de récompense.</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal de confirmation */}
      {confirmationOpen && selectedReward && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Confirmer l'échange</h3>
            <p className="text-gray-600 mb-6">
              Êtes-vous sûr de vouloir échanger <span className="font-semibold text-orange-600">{selectedReward.points_required} points</span> contre <span className="font-semibold">{selectedReward.name}</span> ?
            </p>
            <div className="flex justify-end space-x-4">
              <button
                onClick={closeConfirmation}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                onClick={handleRedeem}
                disabled={redeemMutation.isPending}
                className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 disabled:bg-orange-300"
              >
                {redeemMutation.isPending ? 'Échange en cours...' : 'Confirmer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;

