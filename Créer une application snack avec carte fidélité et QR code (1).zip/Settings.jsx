import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';

const Settings = () => {
  const { currentUser } = useAuth();
  const [generalSettings, setGeneralSettings] = useState({
    storeName: 'Snack Food',
    address: '123 Rue du Snack, 75000 Paris',
    phone: '01 23 45 67 89',
    email: 'contact@snackfood.com',
    openingHours: {
      monday: '8h00 - 20h00',
      tuesday: '8h00 - 20h00',
      wednesday: '8h00 - 20h00',
      thursday: '8h00 - 20h00',
      friday: '8h00 - 20h00',
      saturday: '9h00 - 22h00',
      sunday: '10h00 - 18h00'
    }
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    lowStockAlerts: true,
    newCustomerAlerts: true,
    rewardRedeemedAlerts: true
  });
  
  const [backupSettings, setBackupSettings] = useState({
    autoBackup: true,
    backupFrequency: 'daily',
    lastBackup: '2025-06-06T14:30:00'
  });
  
  const [successMessage, setSuccessMessage] = useState('');

  // Gérer les changements dans les paramètres généraux
  const handleGeneralChange = (e) => {
    const { name, value } = e.target;
    setGeneralSettings(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Gérer les changements dans les horaires d'ouverture
  const handleHoursChange = (e) => {
    const { name, value } = e.target;
    setGeneralSettings(prev => ({
      ...prev,
      openingHours: {
        ...prev.openingHours,
        [name]: value
      }
    }));
  };

  // Gérer les changements dans les paramètres de notification
  const handleNotificationChange = (e) => {
    const { name, checked } = e.target;
    setNotificationSettings(prev => ({
      ...prev,
      [name]: checked
    }));
  };

  // Gérer les changements dans les paramètres de sauvegarde
  const handleBackupChange = (e) => {
    const { name, value, type, checked } = e.target;
    setBackupSettings(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // Enregistrer les paramètres
  const handleSaveSettings = (e) => {
    e.preventDefault();
    // Simuler l'enregistrement des paramètres
    setTimeout(() => {
      setSuccessMessage('Paramètres enregistrés avec succès');
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    }, 500);
  };

  // Formater la date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-gray-900">Paramètres</h2>
      </div>

      {/* Message de succès */}
      {successMessage && (
        <div className="bg-green-100 border-l-4 border-green-500 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">{successMessage}</p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSaveSettings}>
        {/* Paramètres généraux */}
        <div className="bg-white shadow rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Paramètres généraux</h3>
          </div>
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="storeName" className="block text-sm font-medium text-gray-700 mb-1">
                Nom du snack
              </label>
              <input
                type="text"
                id="storeName"
                name="storeName"
                value={generalSettings.storeName}
                onChange={handleGeneralChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                Adresse
              </label>
              <input
                type="text"
                id="address"
                name="address"
                value={generalSettings.address}
                onChange={handleGeneralChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Téléphone
              </label>
              <input
                type="text"
                id="phone"
                name="phone"
                value={generalSettings.phone}
                onChange={handleGeneralChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={generalSettings.email}
                onChange={handleGeneralChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
          </div>
          
          {/* Horaires d'ouverture */}
          <div className="px-6 pb-6">
            <h4 className="text-md font-semibold text-gray-900 mb-4">Horaires d'ouverture</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label htmlFor="monday" className="block text-sm font-medium text-gray-700 mb-1">
                  Lundi
                </label>
                <input
                  type="text"
                  id="monday"
                  name="monday"
                  value={generalSettings.openingHours.monday}
                  onChange={handleHoursChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              <div>
                <label htmlFor="tuesday" className="block text-sm font-medium text-gray-700 mb-1">
                  Mardi
                </label>
                <input
                  type="text"
                  id="tuesday"
                  name="tuesday"
                  value={generalSettings.openingHours.tuesday}
                  onChange={handleHoursChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              <div>
                <label htmlFor="wednesday" className="block text-sm font-medium text-gray-700 mb-1">
                  Mercredi
                </label>
                <input
                  type="text"
                  id="wednesday"
                  name="wednesday"
                  value={generalSettings.openingHours.wednesday}
                  onChange={handleHoursChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              <div>
                <label htmlFor="thursday" className="block text-sm font-medium text-gray-700 mb-1">
                  Jeudi
                </label>
                <input
                  type="text"
                  id="thursday"
                  name="thursday"
                  value={generalSettings.openingHours.thursday}
                  onChange={handleHoursChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              <div>
                <label htmlFor="friday" className="block text-sm font-medium text-gray-700 mb-1">
                  Vendredi
                </label>
                <input
                  type="text"
                  id="friday"
                  name="friday"
                  value={generalSettings.openingHours.friday}
                  onChange={handleHoursChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              <div>
                <label htmlFor="saturday" className="block text-sm font-medium text-gray-700 mb-1">
                  Samedi
                </label>
                <input
                  type="text"
                  id="saturday"
                  name="saturday"
                  value={generalSettings.openingHours.saturday}
                  onChange={handleHoursChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              <div>
                <label htmlFor="sunday" className="block text-sm font-medium text-gray-700 mb-1">
                  Dimanche
                </label>
                <input
                  type="text"
                  id="sunday"
                  name="sunday"
                  value={generalSettings.openingHours.sunday}
                  onChange={handleHoursChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Paramètres de notification */}
        <div className="bg-white shadow rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Notifications</h3>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="emailNotifications"
                name="emailNotifications"
                checked={notificationSettings.emailNotifications}
                onChange={handleNotificationChange}
                className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
              />
              <label htmlFor="emailNotifications" className="ml-2 block text-sm text-gray-900">
                Recevoir des notifications par email
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="lowStockAlerts"
                name="lowStockAlerts"
                checked={notificationSettings.lowStockAlerts}
                onChange={handleNotificationChange}
                className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
              />
              <label htmlFor="lowStockAlerts" className="ml-2 block text-sm text-gray-900">
                Alertes de stock faible
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="newCustomerAlerts"
                name="newCustomerAlerts"
                checked={notificationSettings.newCustomerAlerts}
                onChange={handleNotificationChange}
                className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
              />
              <label htmlFor="newCustomerAlerts" className="ml-2 block text-sm text-gray-900">
                Alertes de nouveaux clients
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="rewardRedeemedAlerts"
                name="rewardRedeemedAlerts"
                checked={notificationSettings.rewardRedeemedAlerts}
                onChange={handleNotificationChange}
                className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
              />
              <label htmlFor="rewardRedeemedAlerts" className="ml-2 block text-sm text-gray-900">
                Alertes de récompenses échangées
              </label>
            </div>
          </div>
        </div>

        {/* Paramètres de sauvegarde */}
        <div className="bg-white shadow rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Sauvegarde des données</h3>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="autoBackup"
                name="autoBackup"
                checked={backupSettings.autoBackup}
                onChange={handleBackupChange}
                className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
              />
              <label htmlFor="autoBackup" className="ml-2 block text-sm text-gray-900">
                Sauvegarde automatique
              </label>
            </div>
            
            <div>
              <label htmlFor="backupFrequency" className="block text-sm font-medium text-gray-700 mb-1">
                Fréquence de sauvegarde
              </label>
              <select
                id="backupFrequency"
                name="backupFrequency"
                value={backupSettings.backupFrequency}
                onChange={handleBackupChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                disabled={!backupSettings.autoBackup}
              >
                <option value="daily">Quotidienne</option>
                <option value="weekly">Hebdomadaire</option>
                <option value="monthly">Mensuelle</option>
              </select>
            </div>
            
            <div>
              <p className="text-sm text-gray-700">
                Dernière sauvegarde : {formatDate(backupSettings.lastBackup)}
              </p>
            </div>
            
            <div className="pt-4">
              <button
                type="button"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Sauvegarder maintenant
              </button>
            </div>
          </div>
        </div>

        {/* Compte administrateur */}
        <div className="bg-white shadow rounded-lg overflow-hidden mb-8">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Compte administrateur</h3>
          </div>
          <div className="p-6">
            <div className="flex items-center mb-6">
              <div className="h-12 w-12 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div>
                <h4 className="text-md font-semibold text-gray-900">
                  {currentUser?.first_name} {currentUser?.last_name}
                </h4>
                <p className="text-sm text-gray-600">{currentUser?.email}</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <button
                type="button"
                className="w-full px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                Modifier le profil
              </button>
              <button
                type="button"
                className="w-full px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                Changer le mot de passe
              </button>
            </div>
          </div>
        </div>

        {/* Bouton d'enregistrement */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-3 bg-orange-600 text-white font-medium rounded-md shadow-sm hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
          >
            Enregistrer les paramètres
          </button>
        </div>
      </form>
    </div>
  );
};

export default Settings;

