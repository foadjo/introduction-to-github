"""
Routes de gestion des produits pour l'application
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.main import db
from src.models.user import User
from src.models.product import Product

products_bp = Blueprint('products', __name__)

# Fonction utilitaire pour vérifier si l'utilisateur est admin
def is_admin(user_id):
    """Vérifier si l'utilisateur est un administrateur"""
    user = User.query.get(user_id)
    return user and user.role == 'admin'


@products_bp.route('', methods=['GET'])
def get_products():
    """Récupérer tous les produits"""
    # Paramètres de filtrage optionnels
    category = request.args.get('category')
    available_only = request.args.get('available', 'false').lower() == 'true'
    
    # Construire la requête
    query = Product.query
    
    if category:
        query = query.filter_by(category=category)
    
    if available_only:
        query = query.filter_by(is_available=True)
    
    # Exécuter la requête
    products = query.all()
    
    return jsonify([product.to_dict() for product in products]), 200


@products_bp.route('/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Récupérer un produit par son ID"""
    product = Product.query.get(product_id)
    
    if not product:
        return jsonify({'message': 'Produit non trouvé'}), 404
    
    return jsonify(product.to_dict()), 200


@products_bp.route('', methods=['POST'])
@jwt_required()
def create_product():
    """Créer un nouveau produit (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    data = request.get_json()
    
    # Vérifier les données requises
    required_fields = ['name', 'price', 'category']
    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Le champ {field} est requis'}), 400
    
    # Créer un nouveau produit
    product = Product(
        name=data['name'],
        description=data.get('description', ''),
        price=float(data['price']),
        category=data['category'],
        image_url=data.get('image_url', ''),
        is_available=data.get('is_available', True)
    )
    
    db.session.add(product)
    db.session.commit()
    
    return jsonify(product.to_dict()), 201


@products_bp.route('/<int:product_id>', methods=['PUT'])
@jwt_required()
def update_product(product_id):
    """Mettre à jour un produit (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    product = Product.query.get(product_id)
    
    if not product:
        return jsonify({'message': 'Produit non trouvé'}), 404
    
    data = request.get_json()
    
    # Mettre à jour les champs du produit
    if 'name' in data:
        product.name = data['name']
    if 'description' in data:
        product.description = data['description']
    if 'price' in data:
        product.price = float(data['price'])
    if 'category' in data:
        product.category = data['category']
    if 'image_url' in data:
        product.image_url = data['image_url']
    if 'is_available' in data:
        product.is_available = data['is_available']
    
    db.session.commit()
    
    return jsonify(product.to_dict()), 200


@products_bp.route('/<int:product_id>', methods=['DELETE'])
@jwt_required()
def delete_product(product_id):
    """Supprimer un produit (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    product = Product.query.get(product_id)
    
    if not product:
        return jsonify({'message': 'Produit non trouvé'}), 404
    
    db.session.delete(product)
    db.session.commit()
    
    return jsonify({'message': 'Produit supprimé avec succès'}), 200


@products_bp.route('/categories', methods=['GET'])
def get_categories():
    """Récupérer toutes les catégories de produits"""
    categories = db.session.query(Product.category).distinct().all()
    category_list = [category[0] for category in categories]
    
    return jsonify(category_list), 200

