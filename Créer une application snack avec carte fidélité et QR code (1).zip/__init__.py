"""
Initialisation des modèles de l'application
"""

from src.models.user import User
from src.models.product import Product
from src.models.loyalty import LoyaltyCard
from src.models.transaction import Transaction, TransactionDetail
from src.models.reward import Reward, UsedReward
from src.models.system import SystemSetting

