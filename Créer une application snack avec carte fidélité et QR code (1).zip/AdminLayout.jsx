import { Outlet, Link, useLocation, Navigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const AdminLayout = () => {
  const { currentUser, isAdmin, logout } = useAuth();
  const location = useLocation();

  // Rediriger si l'utilisateur n'est pas connecté ou n'est pas admin
  if (!currentUser || !isAdmin()) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Vérifier si le lien est actif
  const isActive = (path) => {
    return location.pathname === path ? 'bg-gray-800 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white';
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900">
        <div className="flex items-center justify-between h-16 px-4 bg-gray-800 text-white">
          <span className="text-xl font-semibold">Admin Panel</span>
          <Link to="/" className="text-sm text-gray-300 hover:text-white">
            Retour
          </Link>
        </div>
        <nav className="mt-5 px-2">
          <Link
            to="/admin"
            className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/admin')}`}
          >
            Tableau de bord
          </Link>
          <Link
            to="/admin/products"
            className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/admin/products')}`}
          >
            Produits
          </Link>
          <Link
            to="/admin/customers"
            className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/admin/customers')}`}
          >
            Clients
          </Link>
          <Link
            to="/admin/loyalty"
            className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/admin/loyalty')}`}
          >
            Fidélité
          </Link>
          <Link
            to="/admin/scanner"
            className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/admin/scanner')}`}
          >
            Scanner
          </Link>
          <Link
            to="/admin/settings"
            className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive('/admin/settings')}`}
          >
            Paramètres
          </Link>
          <button
            onClick={logout}
            className="w-full mt-4 group flex items-center px-2 py-2 text-sm font-medium rounded-md text-red-300 hover:bg-red-900 hover:text-white"
          >
            Déconnexion
          </button>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white shadow">
          <div className="px-4 py-6">
            <h1 className="text-2xl font-semibold text-gray-900">
              {location.pathname === '/admin' && 'Tableau de bord'}
              {location.pathname === '/admin/products' && 'Gestion des produits'}
              {location.pathname === '/admin/customers' && 'Gestion des clients'}
              {location.pathname === '/admin/loyalty' && 'Gestion de la fidélité'}
              {location.pathname === '/admin/scanner' && 'Scanner QR Code'}
              {location.pathname === '/admin/settings' && 'Paramètres'}
            </h1>
          </div>
        </header>
        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;

