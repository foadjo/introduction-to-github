import { useQuery } from '@tanstack/react-query';
import { loyaltyService, transactionService, userService } from '../../services/api';

const Dashboard = () => {
  // Récupérer les statistiques de fidélité
  const { data: loyaltyStats, isLoading: isLoadingLoyalty } = useQuery({
    queryKey: ['loyaltyStats'],
    queryFn: loyaltyService.getStats,
    // Données fictives pour le développement
    placeholderData: {
      totalPoints: 15420,
      pointsThisMonth: 3250,
      rewardsRedeemed: 47,
      averagePointsPerUser: 128
    }
  });

  // Récupérer les statistiques de transactions
  const { data: transactionStats, isLoading: isLoadingTransactions } = useQuery({
    queryKey: ['transactionStats'],
    queryFn: transactionService.getStats,
    // Données fictives pour le développement
    placeholderData: {
      total_transactions: 342,
      total_revenue: 2847.50,
      today_transactions: 23,
      today_revenue: 187.30,
      month_transactions: 156,
      month_revenue: 1245.80,
      top_products: [
        { id: 1, name: 'Sandwich Poulet', quantity: 45 },
        { id: 2, name: 'Menu Sandwich', quantity: 38 },
        { id: 3, name: 'Coca-Cola', quantity: 67 },
        { id: 4, name: 'Salade César', quantity: 22 },
        { id: 5, name: 'Panini 3 Fromages', quantity: 31 }
      ]
    }
  });

  // Récupérer le nombre d'utilisateurs
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ['users'],
    queryFn: userService.getAll,
    // Données fictives pour le développement
    placeholderData: [
      { id: 1, role: 'client' },
      { id: 2, role: 'client' },
      { id: 3, role: 'client' },
      { id: 4, role: 'admin' }
    ]
  });

  const clientCount = users?.filter(user => user.role === 'client').length || 0;

  // Formater les nombres
  const formatNumber = (num) => {
    return new Intl.NumberFormat('fr-FR').format(num);
  };

  // Formater les montants
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Tableau de bord</h1>
          <p className="text-gray-600 mt-2">Vue d'ensemble de votre snack food</p>
        </div>

        {/* Statistiques principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Chiffre d'affaires du jour */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-green-100 rounded-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">CA Aujourd'hui</p>
                {isLoadingTransactions ? (
                  <div className="h-6 w-16 bg-gray-200 rounded animate-pulse"></div>
                ) : (
                  <p className="text-2xl font-bold text-gray-900">
                    {formatCurrency(transactionStats?.today_revenue || 0)}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Transactions du jour */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-100 rounded-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Transactions</p>
                {isLoadingTransactions ? (
                  <div className="h-6 w-12 bg-gray-200 rounded animate-pulse"></div>
                ) : (
                  <p className="text-2xl font-bold text-gray-900">
                    {formatNumber(transactionStats?.today_transactions || 0)}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Clients fidèles */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-purple-100 rounded-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Clients</p>
                {isLoadingUsers ? (
                  <div className="h-6 w-12 bg-gray-200 rounded animate-pulse"></div>
                ) : (
                  <p className="text-2xl font-bold text-gray-900">
                    {formatNumber(clientCount)}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Points distribués ce mois */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-orange-100 rounded-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                  </svg>
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Points ce mois</p>
                {isLoadingLoyalty ? (
                  <div className="h-6 w-16 bg-gray-200 rounded animate-pulse"></div>
                ) : (
                  <p className="text-2xl font-bold text-gray-900">
                    {formatNumber(loyaltyStats?.pointsThisMonth || 0)}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Produits les plus vendus */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Produits populaires</h2>
            </div>
            <div className="p-6">
              {isLoadingTransactions ? (
                <div className="space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex justify-between items-center">
                      <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
                      <div className="h-4 w-12 bg-gray-200 rounded animate-pulse"></div>
                    </div>
                  ))}
                </div>
              ) : transactionStats?.top_products?.length > 0 ? (
                <div className="space-y-3">
                  {transactionStats.top_products.map((product, index) => (
                    <div key={product.id} className="flex justify-between items-center">
                      <div className="flex items-center">
                        <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-orange-100 text-orange-600 text-xs font-medium mr-3">
                          {index + 1}
                        </span>
                        <span className="text-sm font-medium text-gray-900">{product.name}</span>
                      </div>
                      <span className="text-sm text-gray-600">{product.quantity} vendus</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600 text-center">Aucune donnée disponible</p>
              )}
            </div>
          </div>

          {/* Statistiques de fidélité */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Programme de fidélité</h2>
            </div>
            <div className="p-6">
              {isLoadingLoyalty ? (
                <div className="space-y-4">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="flex justify-between items-center">
                      <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
                      <div className="h-4 w-16 bg-gray-200 rounded animate-pulse"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Points totaux</span>
                    <span className="text-sm font-bold text-gray-900">
                      {formatNumber(loyaltyStats?.totalPoints || 0)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Points ce mois</span>
                    <span className="text-sm font-bold text-green-600">
                      +{formatNumber(loyaltyStats?.pointsThisMonth || 0)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Récompenses échangées</span>
                    <span className="text-sm font-bold text-gray-900">
                      {formatNumber(loyaltyStats?.rewardsRedeemed || 0)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-600">Moyenne par client</span>
                    <span className="text-sm font-bold text-gray-900">
                      {formatNumber(loyaltyStats?.averagePointsPerUser || 0)} pts
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Résumé mensuel */}
        <div className="mt-8 bg-white rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Résumé du mois</h2>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <p className="text-sm font-medium text-gray-600 mb-1">Chiffre d'affaires</p>
                {isLoadingTransactions ? (
                  <div className="h-8 w-24 bg-gray-200 rounded animate-pulse mx-auto"></div>
                ) : (
                  <p className="text-2xl font-bold text-green-600">
                    {formatCurrency(transactionStats?.month_revenue || 0)}
                  </p>
                )}
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-gray-600 mb-1">Transactions</p>
                {isLoadingTransactions ? (
                  <div className="h-8 w-16 bg-gray-200 rounded animate-pulse mx-auto"></div>
                ) : (
                  <p className="text-2xl font-bold text-blue-600">
                    {formatNumber(transactionStats?.month_transactions || 0)}
                  </p>
                )}
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-gray-600 mb-1">Panier moyen</p>
                {isLoadingTransactions ? (
                  <div className="h-8 w-20 bg-gray-200 rounded animate-pulse mx-auto"></div>
                ) : (
                  <p className="text-2xl font-bold text-purple-600">
                    {transactionStats?.month_transactions > 0 
                      ? formatCurrency((transactionStats?.month_revenue || 0) / transactionStats.month_transactions)
                      : formatCurrency(0)
                    }
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

