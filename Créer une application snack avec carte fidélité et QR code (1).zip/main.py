"""
Configuration principale de l'application Flask
"""

import os
from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_sqlalchemy import SQLAlchemy
from datetime import timedelta

# Initialisation de l'extension SQLAlchemy
db = SQLAlchemy()

def create_app():
    """Fonction de création de l'application Flask"""
    
    # Initialisation de l'application Flask
    app = Flask(__name__)
    
    # Configuration de l'application
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev_secret_key_change_in_production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///snack_food.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Configuration JWT
    app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'jwt_dev_key_change_in_production')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
    
    # Initialisation des extensions
    db.init_app(app)
    jwt = JWTManager(app)
    
    # Configuration CORS pour permettre les requêtes cross-origin
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    # Enregistrement des blueprints
    from src.routes.auth import auth_bp
    from src.routes.products import products_bp
    from src.routes.users import users_bp
    from src.routes.loyalty import loyalty_bp
    from src.routes.rewards import rewards_bp
    from src.routes.transactions import transactions_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(products_bp, url_prefix='/api/products')
    app.register_blueprint(users_bp, url_prefix='/api/users')
    app.register_blueprint(loyalty_bp, url_prefix='/api/loyalty')
    app.register_blueprint(rewards_bp, url_prefix='/api/rewards')
    app.register_blueprint(transactions_bp, url_prefix='/api/transactions')
    
    # Création des tables de la base de données
    with app.app_context():
        db.create_all()
        
        # Création d'un utilisateur admin par défaut si aucun n'existe
        from src.models.user import User
        if not User.query.filter_by(role='admin').first():
            admin = User(
                first_name='Admin',
                last_name='User',
                email='admin@snackfood.com',
                role='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
    
    return app

