import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Informations */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Snack Food</h3>
            <p className="text-gray-300 mb-2">Votre snack préféré avec des produits frais et délicieux.</p>
            <p className="text-gray-300">
              <span className="font-semibold">Adresse:</span> 123 Rue du Snack, 75000 Paris
            </p>
            <p className="text-gray-300">
              <span className="font-semibold">Téléphone:</span> 01 23 45 67 89
            </p>
          </div>

          {/* Liens rapides */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Liens rapides</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white transition">
                  Accueil
                </Link>
              </li>
              <li>
                <Link to="/menu" className="text-gray-300 hover:text-white transition">
                  Menu
                </Link>
              </li>
              <li>
                <Link to="/loyalty" className="text-gray-300 hover:text-white transition">
                  Carte de fidélité
                </Link>
              </li>
              <li>
                <Link to="/rewards" className="text-gray-300 hover:text-white transition">
                  Récompenses
                </Link>
              </li>
            </ul>
          </div>

          {/* Horaires */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Horaires d'ouverture</h3>
            <ul className="space-y-2 text-gray-300">
              <li className="flex justify-between">
                <span>Lundi - Vendredi:</span>
                <span>8h00 - 20h00</span>
              </li>
              <li className="flex justify-between">
                <span>Samedi:</span>
                <span>9h00 - 22h00</span>
              </li>
              <li className="flex justify-between">
                <span>Dimanche:</span>
                <span>10h00 - 18h00</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-6 border-t border-gray-700 text-center text-gray-400">
          <p>&copy; {currentYear} Snack Food. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

