import React from 'react';

const SimpleApp = () => {
  return (
    <div style={{ 
      fontFamily: 'Arial, sans-serif',
      backgroundColor: '#f9fafb',
      minHeight: '100vh',
      padding: '20px'
    }}>
      {/* Navigation */}
      <nav style={{
        backgroundColor: '#ea580c',
        color: 'white',
        padding: '1rem',
        borderRadius: '8px',
        marginBottom: '2rem'
      }}>
        <div style={{ 
          maxWidth: '1200px', 
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <h1 style={{ margin: 0, fontSize: '1.5rem' }}>🥪 Mon Snack</h1>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <a href="#" style={{ color: 'white', textDecoration: 'none' }}>Accueil</a>
            <a href="#menu" style={{ color: 'white', textDecoration: 'none' }}>Menu</a>
            <a href="#loyalty" style={{ color: 'white', textDecoration: 'none' }}>Fidélité</a>
            <a href="#admin" style={{ color: 'white', textDecoration: 'none' }}>Admin</a>
          </div>
        </div>
      </nav>

      {/* Contenu principal */}
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Section Héro */}
        <section style={{
          backgroundColor: 'white',
          padding: '3rem',
          borderRadius: '12px',
          textAlign: 'center',
          marginBottom: '2rem',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ 
            fontSize: '2.5rem', 
            marginBottom: '1rem',
            color: '#111827'
          }}>
            Bienvenue chez Mon Snack
          </h2>
          <p style={{ 
            fontSize: '1.2rem', 
            color: '#6b7280',
            marginBottom: '2rem'
          }}>
            Découvrez nos délicieux sandwichs, salades et boissons fraîches. 
            Rejoignez notre programme de fidélité et gagnez des points à chaque achat !
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
            <button style={{
              backgroundColor: '#ea580c',
              color: 'white',
              padding: '12px 24px',
              border: 'none',
              borderRadius: '6px',
              fontSize: '1rem',
              cursor: 'pointer'
            }}>
              Voir le menu
            </button>
            <button style={{
              backgroundColor: '#6b7280',
              color: 'white',
              padding: '12px 24px',
              border: 'none',
              borderRadius: '6px',
              fontSize: '1rem',
              cursor: 'pointer'
            }}>
              S'inscrire
            </button>
          </div>
        </section>

        {/* Fonctionnalités */}
        <section id="features" style={{ marginBottom: '2rem' }}>
          <h3 style={{ 
            textAlign: 'center', 
            marginBottom: '2rem',
            fontSize: '2rem',
            color: '#111827'
          }}>
            Nos fonctionnalités
          </h3>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '1.5rem'
          }}>
            {/* Carte de fidélité */}
            <div style={{
              backgroundColor: 'white',
              padding: '2rem',
              borderRadius: '12px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎯</div>
              <h4 style={{ marginBottom: '1rem', color: '#111827' }}>Carte de fidélité</h4>
              <p style={{ color: '#6b7280' }}>
                Gagnez 10 points par euro dépensé et échangez-les contre des récompenses exclusives.
              </p>
            </div>

            {/* Scanner QR */}
            <div style={{
              backgroundColor: 'white',
              padding: '2rem',
              borderRadius: '12px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📱</div>
              <h4 style={{ marginBottom: '1rem', color: '#111827' }}>Scanner QR Code</h4>
              <p style={{ color: '#6b7280' }}>
                Présentez votre QR code à chaque achat pour accumuler automatiquement vos points.
              </p>
            </div>

            {/* Administration */}
            <div style={{
              backgroundColor: 'white',
              padding: '2rem',
              borderRadius: '12px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>⚙️</div>
              <h4 style={{ marginBottom: '1rem', color: '#111827' }}>Interface Admin</h4>
              <p style={{ color: '#6b7280' }}>
                Gérez vos produits, clients et programme de fidélité depuis une interface dédiée.
              </p>
            </div>
          </div>
        </section>

        {/* Menu aperçu */}
        <section id="menu" style={{ marginBottom: '2rem' }}>
          <h3 style={{ 
            textAlign: 'center', 
            marginBottom: '2rem',
            fontSize: '2rem',
            color: '#111827'
          }}>
            Nos spécialités
          </h3>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '1rem'
          }}>
            {[
              { name: 'Sandwich Poulet', price: '5.50€', desc: 'Poulet grillé, salade, tomate' },
              { name: 'Panini 3 Fromages', price: '6.00€', desc: 'Mozzarella, chèvre, emmental' },
              { name: 'Salade César', price: '7.50€', desc: 'Salade, poulet, parmesan, croûtons' },
              { name: 'Menu Complet', price: '9.90€', desc: 'Sandwich + boisson + dessert' }
            ].map((item, index) => (
              <div key={index} style={{
                backgroundColor: 'white',
                padding: '1.5rem',
                borderRadius: '8px',
                boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
              }}>
                <h5 style={{ marginBottom: '0.5rem', color: '#111827' }}>{item.name}</h5>
                <p style={{ color: '#6b7280', marginBottom: '0.5rem', fontSize: '0.9rem' }}>{item.desc}</p>
                <p style={{ color: '#ea580c', fontWeight: 'bold', fontSize: '1.1rem' }}>{item.price}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Programme de fidélité */}
        <section id="loyalty" style={{
          backgroundColor: 'white',
          padding: '2rem',
          borderRadius: '12px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <h3 style={{ 
            marginBottom: '1rem',
            fontSize: '2rem',
            color: '#111827'
          }}>
            Programme de fidélité
          </h3>
          <p style={{ color: '#6b7280', marginBottom: '2rem' }}>
            Rejoignez notre programme et profitez d'avantages exclusifs !
          </p>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '1rem',
            marginBottom: '2rem'
          }}>
            <div style={{ padding: '1rem' }}>
              <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🥤</div>
              <h5 style={{ color: '#111827' }}>Boisson gratuite</h5>
              <p style={{ color: '#ea580c', fontWeight: 'bold' }}>100 points</p>
            </div>
            <div style={{ padding: '1rem' }}>
              <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🥪</div>
              <h5 style={{ color: '#111827' }}>Sandwich gratuit</h5>
              <p style={{ color: '#ea580c', fontWeight: 'bold' }}>200 points</p>
            </div>
            <div style={{ padding: '1rem' }}>
              <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🍽️</div>
              <h5 style={{ color: '#111827' }}>Menu complet</h5>
              <p style={{ color: '#ea580c', fontWeight: 'bold' }}>500 points</p>
            </div>
          </div>
          <button style={{
            backgroundColor: '#ea580c',
            color: 'white',
            padding: '12px 24px',
            border: 'none',
            borderRadius: '6px',
            fontSize: '1rem',
            cursor: 'pointer'
          }}>
            Rejoindre le programme
          </button>
        </section>
      </div>

      {/* Footer */}
      <footer style={{
        marginTop: '3rem',
        padding: '2rem',
        textAlign: 'center',
        color: '#6b7280'
      }}>
        <p>&copy; 2025 Mon Snack - Application de fidélité avec QR Code</p>
        <p style={{ marginTop: '0.5rem', fontSize: '0.9rem' }}>
          Backend: Flask | Frontend: React | Scanner QR Code intégré
        </p>
      </footer>
    </div>
  );
};

export default SimpleApp;

