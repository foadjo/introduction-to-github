"""
Routes de gestion des transactions pour l'application
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.main import db
from src.models.user import User
from src.models.transaction import Transaction, TransactionDetail
from src.models.product import Product
from src.models.loyalty import LoyaltyCard
from src.models.system import SystemSetting
from datetime import datetime

transactions_bp = Blueprint('transactions', __name__)

# Fonction utilitaire pour vérifier si l'utilisateur est admin
def is_admin(user_id):
    """Vérifier si l'utilisateur est un administrateur"""
    user = User.query.get(user_id)
    return user and user.role == 'admin'


@transactions_bp.route('', methods=['GET'])
@jwt_required()
def get_transactions():
    """Récupérer les transactions de l'utilisateur ou toutes les transactions (admin)"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    # Paramètres de filtrage optionnels
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    # Construire la requête
    query = Transaction.query
    
    # Si l'utilisateur n'est pas admin, filtrer par user_id
    if not is_admin(user_id):
        query = query.filter_by(user_id=user_id)
    
    # Filtrer par date si spécifié
    if start_date:
        try:
            start_date = datetime.fromisoformat(start_date)
            query = query.filter(Transaction.transaction_date >= start_date)
        except ValueError:
            return jsonify({'message': 'Format de date de début invalide'}), 400
    
    if end_date:
        try:
            end_date = datetime.fromisoformat(end_date)
            query = query.filter(Transaction.transaction_date <= end_date)
        except ValueError:
            return jsonify({'message': 'Format de date de fin invalide'}), 400
    
    # Exécuter la requête
    transactions = query.order_by(Transaction.transaction_date.desc()).all()
    
    return jsonify([transaction.to_dict() for transaction in transactions]), 200


@transactions_bp.route('/<int:transaction_id>', methods=['GET'])
@jwt_required()
def get_transaction(transaction_id):
    """Récupérer une transaction par son ID"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    transaction = Transaction.query.get(transaction_id)
    
    if not transaction:
        return jsonify({'message': 'Transaction non trouvée'}), 404
    
    # Vérifier si l'utilisateur est autorisé à voir cette transaction
    if not is_admin(user_id) and transaction.user_id != user_id:
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    return jsonify(transaction.to_dict()), 200


@transactions_bp.route('', methods=['POST'])
@jwt_required()
def create_transaction():
    """Créer une nouvelle transaction"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    data = request.get_json()
    
    # Vérifier les données requises
    if 'items' not in data or not data['items']:
        return jsonify({'message': 'Aucun produit dans la transaction'}), 400
    
    # Vérifier si l'utilisateur a une carte de fidélité
    if not user.loyalty_card and user.role == 'client':
        return jsonify({'message': 'Vous n\'avez pas de carte de fidélité'}), 400
    
    # Calculer le montant total
    total_amount = 0
    items = []
    
    for item in data['items']:
        if 'product_id' not in item or 'quantity' not in item:
            return jsonify({'message': 'Données de produit invalides'}), 400
        
        product = Product.query.get(item['product_id'])
        if not product:
            return jsonify({'message': f'Produit {item["product_id"]} non trouvé'}), 404
        
        if not product.is_available:
            return jsonify({'message': f'Produit {product.name} non disponible'}), 400
        
        quantity = int(item['quantity'])
        if quantity <= 0:
            return jsonify({'message': 'La quantité doit être positive'}), 400
        
        item_total = product.price * quantity
        total_amount += item_total
        
        items.append({
            'product': product,
            'quantity': quantity,
            'price': product.price
        })
    
    # Calculer les points à attribuer
    points_per_euro = int(SystemSetting.get_value('points_per_euro', '10'))
    points_earned = int(total_amount * points_per_euro)
    
    # Créer la transaction
    transaction = Transaction(
        user_id=user_id,
        total_amount=total_amount,
        points_earned=points_earned
    )
    
    db.session.add(transaction)
    db.session.flush()  # Pour obtenir l'ID de la transaction
    
    # Créer les détails de la transaction
    for item in items:
        detail = TransactionDetail(
            transaction_id=transaction.id,
            product_id=item['product'].id,
            quantity=item['quantity'],
            price=item['price']
        )
        db.session.add(detail)
    
    # Mettre à jour les points de fidélité si l'utilisateur est un client
    if user.role == 'client' and user.loyalty_card:
        user.loyalty_card.points += points_earned
    
    db.session.commit()
    
    return jsonify({
        'transaction': transaction.to_dict(),
        'points_earned': points_earned,
        'total_points': user.loyalty_card.points if user.loyalty_card else 0
    }), 201


@transactions_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_transaction_stats():
    """Récupérer les statistiques des transactions (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    # Statistiques globales
    total_transactions = Transaction.query.count()
    total_revenue = db.session.query(db.func.sum(Transaction.total_amount)).scalar() or 0
    
    # Statistiques du jour
    today = datetime.utcnow().date()
    today_transactions = Transaction.query.filter(
        db.func.date(Transaction.transaction_date) == today
    ).count()
    today_revenue = db.session.query(db.func.sum(Transaction.total_amount)).filter(
        db.func.date(Transaction.transaction_date) == today
    ).scalar() or 0
    
    # Statistiques du mois
    current_month = datetime.utcnow().month
    current_year = datetime.utcnow().year
    month_transactions = Transaction.query.filter(
        db.extract('month', Transaction.transaction_date) == current_month,
        db.extract('year', Transaction.transaction_date) == current_year
    ).count()
    month_revenue = db.session.query(db.func.sum(Transaction.total_amount)).filter(
        db.extract('month', Transaction.transaction_date) == current_month,
        db.extract('year', Transaction.transaction_date) == current_year
    ).scalar() or 0
    
    # Produits les plus vendus
    top_products_query = db.session.query(
        Product.id,
        Product.name,
        db.func.sum(TransactionDetail.quantity).label('total_quantity')
    ).join(
        TransactionDetail, TransactionDetail.product_id == Product.id
    ).group_by(
        Product.id
    ).order_by(
        db.desc('total_quantity')
    ).limit(5)
    
    top_products = [
        {
            'id': product.id,
            'name': product.name,
            'quantity': product.total_quantity
        }
        for product in top_products_query.all()
    ]
    
    return jsonify({
        'total_transactions': total_transactions,
        'total_revenue': total_revenue,
        'today_transactions': today_transactions,
        'today_revenue': today_revenue,
        'month_transactions': month_transactions,
        'month_revenue': month_revenue,
        'top_products': top_products
    }), 200

