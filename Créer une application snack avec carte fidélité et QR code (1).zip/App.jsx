import SimpleApp from './SimpleApp';

const App = () => {
  return <SimpleApp />;
};

export default App;

