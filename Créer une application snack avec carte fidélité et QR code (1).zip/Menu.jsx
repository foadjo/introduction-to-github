import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { productService } from '../services/api';

const Menu = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [filteredProducts, setFilteredProducts] = useState([]);
  
  // Récupérer les produits depuis l'API
  const { data: products, isLoading, error } = useQuery({
    queryKey: ['products'],
    queryFn: productService.getAll,
    // Données fictives pour le développement
    placeholderData: [
      {
        id: 1,
        name: 'Sandwich Poulet',
        description: 'Poulet grillé, salade, tomate, sauce maison',
        price: 5.50,
        category: 'sandwich',
        image_url: '/images/sandwich-poulet.jpg',
        is_available: true
      },
      {
        id: 2,
        name: 'Sandwich Thon',
        description: 'Thon, maïs, salade, œuf, mayonnaise',
        price: 5.00,
        category: 'sandwich',
        image_url: '/images/sandwich-thon.jpg',
        is_available: true
      },
      {
        id: 3,
        name: 'Panini 3 Fromages',
        description: 'Mozzarella, chèvre, emmental, tomate, origan',
        price: 6.00,
        category: 'panini',
        image_url: '/images/panini-fromage.jpg',
        is_available: true
      },
      {
        id: 4,
        name: 'Coca-Cola',
        description: 'Canette 33cl',
        price: 1.50,
        category: 'boisson',
        image_url: '/images/coca.jpg',
        is_available: true
      },
      {
        id: 5,
        name: 'Eau Minérale',
        description: 'Bouteille 50cl',
        price: 1.00,
        category: 'boisson',
        image_url: '/images/eau.jpg',
        is_available: true
      },
      {
        id: 6,
        name: 'Brownie',
        description: 'Chocolat et noix',
        price: 2.50,
        category: 'dessert',
        image_url: '/images/brownie.jpg',
        is_available: true
      },
      {
        id: 7,
        name: 'Salade César',
        description: 'Poulet, croûtons, parmesan, sauce césar',
        price: 7.50,
        category: 'salade',
        image_url: '/images/salade-cesar.jpg',
        is_available: true
      },
      {
        id: 8,
        name: 'Menu Sandwich',
        description: 'Sandwich au choix + boisson + dessert',
        price: 8.50,
        category: 'menu',
        image_url: '/images/menu-sandwich.jpg',
        is_available: true
      }
    ]
  });

  // Filtrer les produits par catégorie
  useEffect(() => {
    if (products) {
      if (activeCategory === 'all') {
        setFilteredProducts(products);
      } else {
        setFilteredProducts(products.filter(product => product.category === activeCategory));
      }
    }
  }, [activeCategory, products]);

  // Catégories disponibles
  const categories = [
    { id: 'all', name: 'Tous' },
    { id: 'sandwich', name: 'Sandwichs' },
    { id: 'panini', name: 'Paninis' },
    { id: 'salade', name: 'Salades' },
    { id: 'boisson', name: 'Boissons' },
    { id: 'dessert', name: 'Desserts' },
    { id: 'menu', name: 'Menus' }
  ];

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Notre Menu</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Découvrez notre sélection de produits frais et délicieux, préparés avec soin pour satisfaire toutes vos envies.
          </p>
        </div>

        {/* Filtres de catégories */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map(category => (
            <button
              key={category.id}
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                activeCategory === category.id
                  ? 'bg-orange-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
              onClick={() => setActiveCategory(category.id)}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Affichage des produits */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-orange-500 border-r-transparent"></div>
            <p className="mt-4 text-gray-600">Chargement des produits...</p>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500">Erreur lors du chargement des produits. Veuillez réessayer.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map(product => (
              <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="h-48 bg-gray-200 relative">
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'https://via.placeholder.com/300x200?text=Image+non+disponible';
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-200">
                      <span className="text-gray-400">Image non disponible</span>
                    </div>
                  )}
                  {!product.is_available && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <span className="text-white font-bold text-lg">Non disponible</span>
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{product.name}</h3>
                    <span className="text-lg font-bold text-orange-600">{product.price.toFixed(2)} €</span>
                  </div>
                  <p className="text-gray-600 text-sm mb-4">{product.description}</p>
                  <button
                    disabled={!product.is_available}
                    className={`w-full py-2 px-4 rounded-md text-sm font-medium ${
                      product.is_available
                        ? 'bg-orange-600 text-white hover:bg-orange-700'
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {product.is_available ? 'Ajouter au panier' : 'Non disponible'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Message si aucun produit */}
        {filteredProducts.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-600">Aucun produit disponible dans cette catégorie.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Menu;

