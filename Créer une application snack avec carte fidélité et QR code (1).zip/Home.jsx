import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Home = () => {
  const { currentUser } = useAuth();

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-orange-500 to-yellow-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <div className="md:w-2/3">
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-6">
              Bienvenue chez Snack Food
            </h1>
            <p className="text-xl text-white mb-8">
              Découvrez nos délicieux snacks et profitez de notre programme de fidélité pour des récompenses exclusives.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/menu"
                className="inline-block bg-white text-orange-600 font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-gray-100 transition"
              >
                Voir le menu
              </Link>
              {!currentUser ? (
                <Link
                  to="/register"
                  className="inline-block bg-orange-700 text-white font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-orange-800 transition"
                >
                  Rejoindre le programme de fidélité
                </Link>
              ) : (
                <Link
                  to="/loyalty"
                  className="inline-block bg-orange-700 text-white font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-orange-800 transition"
                >
                  Ma carte de fidélité
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Pourquoi choisir Snack Food ?</h2>
            <p className="mt-4 text-lg text-gray-600">
              Nous proposons une expérience unique avec des avantages exclusifs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Produits frais</h3>
              <p className="text-gray-600">
                Tous nos produits sont préparés quotidiennement avec des ingrédients frais et de qualité.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Service rapide</h3>
              <p className="text-gray-600">
                Commandez facilement et recevez votre repas rapidement, même aux heures de pointe.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Programme de fidélité</h3>
              <p className="text-gray-600">
                Gagnez des points à chaque achat et échangez-les contre des récompenses exclusives.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Loyalty Program Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="lg:w-1/2 mb-8 lg:mb-0">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Notre programme de fidélité
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Rejoignez notre programme de fidélité et profitez d'avantages exclusifs. Gagnez des points à chaque achat et échangez-les contre des récompenses.
              </p>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  1€ dépensé = 10 points
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  100 points = 1 boisson gratuite
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  200 points = 1 sandwich gratuit
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  500 points = 1 menu complet gratuit
                </li>
              </ul>
              <div className="mt-8">
                {!currentUser ? (
                  <Link
                    to="/register"
                    className="inline-block bg-orange-600 text-white font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-orange-700 transition"
                  >
                    S'inscrire maintenant
                  </Link>
                ) : (
                  <Link
                    to="/loyalty"
                    className="inline-block bg-orange-600 text-white font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-orange-700 transition"
                  >
                    Voir ma carte
                  </Link>
                )}
              </div>
            </div>
            <div className="lg:w-2/5">
              <div className="bg-gradient-to-br from-orange-500 to-yellow-500 rounded-xl shadow-xl p-8 text-white">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold">Carte de fidélité</h3>
                  <p className="text-orange-100">Scannez pour gagner des points</p>
                </div>
                <div className="bg-white p-4 rounded-lg mb-6 flex justify-center">
                  {/* Placeholder pour le QR code */}
                  <div className="w-48 h-48 bg-gray-200 flex items-center justify-center">
                    <span className="text-gray-500">QR Code</span>
                  </div>
                </div>
                <div className="text-center">
                  <p className="font-semibold mb-2">Comment ça marche :</p>
                  <p className="text-sm text-orange-100">
                    Présentez votre QR code lors de vos achats pour accumuler des points et profiter de récompenses exclusives.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Prêt à découvrir nos délicieux snacks ?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Rejoignez-nous dès aujourd'hui et commencez à profiter de notre programme de fidélité.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/menu"
              className="inline-block bg-orange-600 text-white font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-orange-700 transition"
            >
              Voir le menu
            </Link>
            {!currentUser ? (
              <Link
                to="/register"
                className="inline-block bg-white text-gray-900 font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-gray-100 transition"
              >
                S'inscrire
              </Link>
            ) : (
              <Link
                to="/scanner"
                className="inline-block bg-white text-gray-900 font-semibold px-6 py-3 rounded-lg shadow-md hover:bg-gray-100 transition"
              >
                Scanner un QR code
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

