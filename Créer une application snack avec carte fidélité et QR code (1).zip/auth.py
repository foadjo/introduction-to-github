"""
Routes d'authentification pour l'application
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from src.main import db
from src.models.user import User
from src.models.loyalty import LoyaltyCard
import uuid

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    """Enregistrement d'un nouvel utilisateur"""
    data = request.get_json()
    
    # Vérifier si l'email existe déjà
    if User.query.filter_by(email=data.get('email')).first():
        return jsonify({'message': 'Cet email est déjà utilisé'}), 400
    
    # Créer un nouvel utilisateur
    user = User(
        first_name=data.get('first_name'),
        last_name=data.get('last_name'),
        email=data.get('email'),
        phone=data.get('phone'),
        role=data.get('role', 'client')
    )
    user.set_password(data.get('password'))
    
    db.session.add(user)
    db.session.commit()
    
    # Créer une carte de fidélité pour le nouvel utilisateur (si c'est un client)
    if user.role == 'client':
        card_number = f"SNACK{user.id:05d}"
        qr_code = f"SNACK-{user.id}-{uuid.uuid4().hex[:8]}"
        
        loyalty_card = LoyaltyCard(
            user_id=user.id,
            card_number=card_number,
            qr_code=qr_code,
            points=0
        )
        
        db.session.add(loyalty_card)
        db.session.commit()
    
    return jsonify({'message': 'Utilisateur créé avec succès'}), 201


@auth_bp.route('/login', methods=['POST'])
def login():
    """Connexion d'un utilisateur"""
    data = request.get_json()
    
    user = User.query.filter_by(email=data.get('email')).first()
    
    if not user or not user.check_password(data.get('password')):
        return jsonify({'message': 'Email ou mot de passe incorrect'}), 401
    
    if not user.is_active:
        return jsonify({'message': 'Ce compte a été désactivé'}), 401
    
    # Créer un token JWT
    access_token = create_access_token(identity=user.id)
    
    # Récupérer les informations de la carte de fidélité si c'est un client
    loyalty_card = None
    if user.role == 'client' and user.loyalty_card:
        loyalty_card = {
            'card_number': user.loyalty_card.card_number,
            'qr_code': user.loyalty_card.qr_code,
            'points': user.loyalty_card.points
        }
    
    return jsonify({
        'token': access_token,
        'user': {
            'id': user.id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email,
            'role': user.role,
            'loyalty_card': loyalty_card
        }
    }), 200


@auth_bp.route('/profile', methods=['GET'])
@jwt_required()
def profile():
    """Récupérer le profil de l'utilisateur connecté"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    # Récupérer les informations de la carte de fidélité si c'est un client
    loyalty_card = None
    if user.role == 'client' and user.loyalty_card:
        loyalty_card = {
            'card_number': user.loyalty_card.card_number,
            'qr_code': user.loyalty_card.qr_code,
            'points': user.loyalty_card.points
        }
    
    return jsonify({
        'user': {
            'id': user.id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email,
            'phone': user.phone,
            'role': user.role,
            'loyalty_card': loyalty_card
        }
    }), 200


@auth_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    """Mettre à jour le profil de l'utilisateur connecté"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    data = request.get_json()
    
    # Mettre à jour les informations de l'utilisateur
    if 'first_name' in data:
        user.first_name = data['first_name']
    if 'last_name' in data:
        user.last_name = data['last_name']
    if 'phone' in data:
        user.phone = data['phone']
    if 'password' in data and data['password']:
        user.set_password(data['password'])
    
    db.session.commit()
    
    return jsonify({'message': 'Profil mis à jour avec succès'}), 200

