// Service API pour communiquer avec le backend

import axios from 'axios';

// Créer une instance axios avec la configuration de base
const api = axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Intercepteur pour ajouter le token d'authentification aux requêtes
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Service d'authentification
export const authService = {
  // Inscription d'un nouvel utilisateur
  register: async (userData) => {
    try {
      const response = await api.post('/auth/register', userData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de l\'inscription' };
    }
  },

  // Connexion d'un utilisateur
  login: async (credentials) => {
    try {
      const response = await api.post('/auth/login', credentials);
      // Stocker le token dans le localStorage
      localStorage.setItem('token', response.data.token);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la connexion' };
    }
  },

  // Déconnexion
  logout: () => {
    localStorage.removeItem('token');
  },

  // Récupérer le profil de l'utilisateur connecté
  getProfile: async () => {
    try {
      const response = await api.get('/auth/profile');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération du profil' };
    }
  },

  // Mettre à jour le profil de l'utilisateur
  updateProfile: async (userData) => {
    try {
      const response = await api.put('/auth/profile', userData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la mise à jour du profil' };
    }
  }
};

// Service de gestion des produits
export const productService = {
  // Récupérer tous les produits
  getAll: async (params = {}) => {
    try {
      const response = await api.get('/products', { params });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des produits' };
    }
  },

  // Récupérer un produit par son ID
  getById: async (id) => {
    try {
      const response = await api.get(`/products/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération du produit' };
    }
  },

  // Créer un nouveau produit (admin)
  create: async (productData) => {
    try {
      const response = await api.post('/products', productData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la création du produit' };
    }
  },

  // Mettre à jour un produit (admin)
  update: async (id, productData) => {
    try {
      const response = await api.put(`/products/${id}`, productData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la mise à jour du produit' };
    }
  },

  // Supprimer un produit (admin)
  delete: async (id) => {
    try {
      const response = await api.delete(`/products/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la suppression du produit' };
    }
  },

  // Récupérer toutes les catégories
  getCategories: async () => {
    try {
      const response = await api.get('/products/categories');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des catégories' };
    }
  }
};

// Service de gestion des utilisateurs (admin)
export const userService = {
  // Récupérer tous les utilisateurs
  getAll: async (params = {}) => {
    try {
      const response = await api.get('/users', { params });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des utilisateurs' };
    }
  },

  // Récupérer un utilisateur par son ID
  getById: async (id) => {
    try {
      const response = await api.get(`/users/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération de l\'utilisateur' };
    }
  },

  // Mettre à jour un utilisateur
  update: async (id, userData) => {
    try {
      const response = await api.put(`/users/${id}`, userData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la mise à jour de l\'utilisateur' };
    }
  },

  // Créer une carte de fidélité pour un utilisateur
  createLoyaltyCard: async (userId) => {
    try {
      const response = await api.post(`/users/${userId}/loyalty-card`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la création de la carte de fidélité' };
    }
  },

  // Mettre à jour les points de fidélité d'un utilisateur
  updateLoyaltyPoints: async (userId, points) => {
    try {
      const response = await api.put(`/users/${userId}/loyalty-card`, { points });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la mise à jour des points' };
    }
  }
};

// Service de gestion de la fidélité
export const loyaltyService = {
  // Récupérer la carte de fidélité de l'utilisateur connecté
  getCard: async () => {
    try {
      const response = await api.get('/loyalty/card');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération de la carte de fidélité' };
    }
  },

  // Scanner un QR code (admin)
  scanQrCode: async (data) => {
    try {
      const response = await api.post('/loyalty/scan', data);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors du scan du QR code' };
    }
  },

  // Récupérer les règles du programme de fidélité
  getRules: async () => {
    try {
      const response = await api.get('/loyalty/rules');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des règles' };
    }
  },

  // Mettre à jour les règles du programme de fidélité (admin)
  updateRules: async (rulesData) => {
    try {
      const response = await api.put('/loyalty/rules', rulesData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la mise à jour des règles' };
    }
  },

  // Récupérer les statistiques du programme de fidélité (admin)
  getStats: async () => {
    try {
      const response = await api.get('/loyalty/stats');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des statistiques' };
    }
  },

  // Récupérer toutes les récompenses
  getRewards: async (params = {}) => {
    try {
      const response = await api.get('/rewards', { params });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des récompenses' };
    }
  },

  // Récupérer une récompense par son ID
  getRewardById: async (id) => {
    try {
      const response = await api.get(`/rewards/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération de la récompense' };
    }
  },

  // Créer une nouvelle récompense (admin)
  createReward: async (rewardData) => {
    try {
      const response = await api.post('/rewards', rewardData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la création de la récompense' };
    }
  },

  // Mettre à jour une récompense (admin)
  updateReward: async (id, rewardData) => {
    try {
      const response = await api.put(`/rewards/${id}`, rewardData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la mise à jour de la récompense' };
    }
  },

  // Échanger des points contre une récompense
  redeemReward: async (rewardId) => {
    try {
      const response = await api.post(`/rewards/redeem/${rewardId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de l\'échange de la récompense' };
    }
  },

  // Récupérer l'historique des récompenses utilisées
  getRewardHistory: async () => {
    try {
      const response = await api.get('/rewards/history');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération de l\'historique' };
    }
  }
};

// Service de gestion des transactions
export const transactionService = {
  // Récupérer toutes les transactions
  getAll: async (params = {}) => {
    try {
      const response = await api.get('/transactions', { params });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des transactions' };
    }
  },

  // Récupérer une transaction par son ID
  getById: async (id) => {
    try {
      const response = await api.get(`/transactions/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération de la transaction' };
    }
  },

  // Créer une nouvelle transaction
  create: async (transactionData) => {
    try {
      const response = await api.post('/transactions', transactionData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la création de la transaction' };
    }
  },

  // Récupérer les statistiques des transactions (admin)
  getStats: async () => {
    try {
      const response = await api.get('/transactions/stats');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Erreur lors de la récupération des statistiques' };
    }
  }
};

export default {
  authService,
  productService,
  userService,
  loyaltyService,
  transactionService
};

