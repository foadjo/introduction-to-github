"""
Modèle de carte de fidélité pour l'application
"""

from datetime import datetime
from src.main import db

class LoyaltyCard(db.Model):
    """Modèle pour les cartes de fidélité des clients"""
    
    __tablename__ = 'loyalty_cards'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    card_number = db.Column(db.String(50), unique=True, nullable=False)
    qr_code = db.Column(db.String(255), unique=True, nullable=False)
    points = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convertir l'objet en dictionnaire"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'card_number': self.card_number,
            'qr_code': self.qr_code,
            'points': self.points,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<LoyaltyCard {self.card_number}>'

