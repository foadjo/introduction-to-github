import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { loyaltyService } from '../../services/api';

const Loyalty = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReward, setEditingReward] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    points_required: '',
    is_active: true
  });
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [loyaltyRules, setLoyaltyRules] = useState({
    points_per_euro: 10
  });

  const queryClient = useQueryClient();

  // Récupérer toutes les récompenses
  const { data: rewards, isLoading, isError, error } = useQuery({
    queryKey: ['rewards'],
    queryFn: () => loyaltyService.getRewards(),
    // Données fictives pour le développement
    placeholderData: [
      {
        id: 1,
        name: 'Boisson gratuite',
        description: 'Une boisson au choix offerte',
        points_required: 100,
        is_active: true
      },
      {
        id: 2,
        name: 'Sandwich gratuit',
        description: 'Un sandwich au choix offert',
        points_required: 200,
        is_active: true
      },
      {
        id: 3,
        name: 'Menu complet',
        description: 'Un menu complet offert (sandwich + boisson + dessert)',
        points_required: 500,
        is_active: true
      },
      {
        id: 4,
        name: 'Réduction de 10%',
        description: 'Une réduction de 10% sur votre prochain achat',
        points_required: 150,
        is_active: true
      },
      {
        id: 5,
        name: 'Dessert gratuit',
        description: 'Un dessert au choix offert',
        points_required: 80,
        is_active: false
      }
    ]
  });

  // Récupérer les règles du programme de fidélité
  const { data: rules } = useQuery({
    queryKey: ['loyaltyRules'],
    queryFn: loyaltyService.getRules,
    onSuccess: (data) => {
      setLoyaltyRules({
        points_per_euro: data.points_per_euro
      });
    },
    // Données fictives pour le développement
    placeholderData: {
      points_per_euro: 10
    }
  });

  // Mutation pour créer une récompense
  const createMutation = useMutation({
    mutationFn: loyaltyService.createReward,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rewards'] });
      setMessage('Récompense créée avec succès !');
      setMessageType('success');
      closeModal();
    },
    onError: (error) => {
      setMessage(error.message || 'Erreur lors de la création de la récompense');
      setMessageType('error');
    }
  });

  // Mutation pour mettre à jour une récompense
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => loyaltyService.updateReward(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rewards'] });
      setMessage('Récompense mise à jour avec succès !');
      setMessageType('success');
      closeModal();
    },
    onError: (error) => {
      setMessage(error.message || 'Erreur lors de la mise à jour de la récompense');
      setMessageType('error');
    }
  });

  // Mutation pour mettre à jour les règles de fidélité
  const updateRulesMutation = useMutation({
    mutationFn: loyaltyService.updateRules,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['loyaltyRules'] });
      setMessage('Règles de fidélité mises à jour avec succès !');
      setMessageType('success');
    },
    onError: (error) => {
      setMessage(error.message || 'Erreur lors de la mise à jour des règles');
      setMessageType('error');
    }
  });

  // Ouvrir le modal pour créer une nouvelle récompense
  const openCreateModal = () => {
    setEditingReward(null);
    setFormData({
      name: '',
      description: '',
      points_required: '',
      is_active: true
    });
    setIsModalOpen(true);
  };

  // Ouvrir le modal pour éditer une récompense
  const openEditModal = (reward) => {
    setEditingReward(reward);
    setFormData({
      name: reward.name,
      description: reward.description,
      points_required: reward.points_required.toString(),
      is_active: reward.is_active
    });
    setIsModalOpen(true);
  };

  // Fermer le modal
  const closeModal = () => {
    setIsModalOpen(false);
    setEditingReward(null);
    setFormData({
      name: '',
      description: '',
      points_required: '',
      is_active: true
    });
  };

  // Gérer les changements dans le formulaire
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // Gérer les changements dans les règles de fidélité
  const handleRulesChange = (e) => {
    const { name, value } = e.target;
    setLoyaltyRules(prev => ({
      ...prev,
      [name]: parseInt(value)
    }));
  };

  // Soumettre le formulaire de récompense
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name || !formData.points_required) {
      setMessage('Veuillez remplir tous les champs obligatoires');
      setMessageType('error');
      return;
    }

    const rewardData = {
      ...formData,
      points_required: parseInt(formData.points_required)
    };

    if (editingReward) {
      updateMutation.mutate({ id: editingReward.id, data: rewardData });
    } else {
      createMutation.mutate(rewardData);
    }
  };

  // Soumettre les règles de fidélité
  const handleRulesSubmit = (e) => {
    e.preventDefault();
    
    // Validation
    if (!loyaltyRules.points_per_euro || loyaltyRules.points_per_euro <= 0) {
      setMessage('Veuillez saisir un nombre de points par euro valide');
      setMessageType('error');
      return;
    }

    updateRulesMutation.mutate(loyaltyRules);
  };

  // Fermer le message
  const closeMessage = () => {
    setMessage('');
    setMessageType('');
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Programme de fidélité</h1>
          <p className="text-gray-600 mt-2">Gérez les récompenses et les règles du programme</p>
        </div>

        {/* Message de statut */}
        {message && (
          <div className={`mb-8 border-l-4 p-4 relative ${
            messageType === 'success' 
              ? 'bg-green-100 border-green-500' 
              : 'bg-red-100 border-red-500'
          }`}>
            <p className={messageType === 'success' ? 'text-green-700' : 'text-red-700'}>
              {message}
            </p>
            <button
              onClick={closeMessage}
              className={`absolute top-2 right-2 hover:opacity-75 ${
                messageType === 'success' ? 'text-green-700' : 'text-red-700'
              }`}
              aria-label="Fermer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Règles du programme */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 bg-orange-50 border-b border-orange-100">
                <h2 className="text-xl font-semibold text-gray-900">Règles du programme</h2>
              </div>
              <div className="p-6">
                <form onSubmit={handleRulesSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="points_per_euro" className="block text-sm font-medium text-gray-700 mb-1">
                      Points par euro dépensé
                    </label>
                    <input
                      type="number"
                      id="points_per_euro"
                      name="points_per_euro"
                      value={loyaltyRules.points_per_euro}
                      onChange={handleRulesChange}
                      min="1"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      Pour chaque euro dépensé, le client gagne ce nombre de points.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={updateRulesMutation.isPending}
                    className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:bg-orange-300"
                  >
                    {updateRulesMutation.isPending ? 'Mise à jour...' : 'Mettre à jour les règles'}
                  </button>
                </form>

                <div className="mt-8 p-4 bg-gray-50 rounded-md">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Exemple</h3>
                  <p className="text-sm text-gray-600">
                    Pour un achat de <span className="font-semibold">10€</span>, le client gagnera <span className="font-semibold text-orange-600">{10 * loyaltyRules.points_per_euro} points</span>.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Liste des récompenses */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 bg-orange-50 border-b border-orange-100 flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900">Récompenses disponibles</h2>
                <button
                  onClick={openCreateModal}
                  className="bg-orange-600 text-white px-3 py-1 rounded-md text-sm hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                >
                  Ajouter
                </button>
              </div>
              
              {isLoading ? (
                <div className="p-6 text-center">
                  <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-orange-500 border-r-transparent"></div>
                  <p className="mt-4 text-gray-600">Chargement des récompenses...</p>
                </div>
              ) : isError ? (
                <div className="p-6">
                  <div className="bg-red-50 border-l-4 border-red-500 p-4">
                    <p className="text-red-700">{error?.message || 'Erreur lors du chargement des récompenses'}</p>
                  </div>
                </div>
              ) : rewards?.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Récompense
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Points requis
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Statut
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {rewards.map((reward) => (
                        <tr key={reward.id}>
                          <td className="px-6 py-4">
                            <div className="text-sm font-medium text-gray-900">{reward.name}</div>
                            <div className="text-sm text-gray-500">{reward.description}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                              {reward.points_required} points
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              reward.is_active
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {reward.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => openEditModal(reward)}
                              className="text-orange-600 hover:text-orange-900"
                            >
                              Modifier
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-6 text-center">
                  <p className="text-gray-600">Aucune récompense disponible</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal de création/édition */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                {editingReward ? 'Modifier la récompense' : 'Ajouter une récompense'}
              </h3>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Nom de la récompense *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>

                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>

                <div>
                  <label htmlFor="points_required" className="block text-sm font-medium text-gray-700 mb-1">
                    Points requis *
                  </label>
                  <input
                    type="number"
                    id="points_required"
                    name="points_required"
                    value={formData.points_required}
                    onChange={handleInputChange}
                    min="1"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="is_active"
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                  />
                  <label htmlFor="is_active" className="ml-2 block text-sm text-gray-900">
                    Récompense active
                  </label>
                </div>

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={createMutation.isPending || updateMutation.isPending}
                    className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 disabled:bg-orange-300"
                  >
                    {createMutation.isPending || updateMutation.isPending
                      ? 'Enregistrement...'
                      : editingReward
                        ? 'Modifier'
                        : 'Créer'
                    }
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Loyalty;

