import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

// Composant de navigation principale
const Navbar = () => {
  const { currentUser, logout, isAdmin } = useAuth();
  const location = useLocation();

  // Vérifier si le lien est actif
  const isActive = (path) => {
    return location.pathname === path ? 'bg-primary text-white' : 'text-gray-700 hover:bg-gray-100';
  };

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="text-xl font-bold text-primary">
                Snack Food
              </Link>
            </div>
          </div>
          
          <div className="flex items-center">
            {currentUser ? (
              <>
                {isAdmin() && (
                  <Link 
                    to="/admin" 
                    className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/admin')}`}
                  >
                    Administration
                  </Link>
                )}
                <Link 
                  to="/menu" 
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/menu')}`}
                >
                  Menu
                </Link>
                <Link 
                  to="/loyalty" 
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/loyalty')}`}
                >
                  Ma Carte
                </Link>
                <Link 
                  to="/rewards" 
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/rewards')}`}
                >
                  Récompenses
                </Link>
                <Link 
                  to="/scanner" 
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/scanner')}`}
                >
                  Scanner
                </Link>
                <button
                  onClick={logout}
                  className="ml-4 px-3 py-2 rounded-md text-sm font-medium text-white bg-red-500 hover:bg-red-600"
                >
                  Déconnexion
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/login')}`}
                >
                  Connexion
                </Link>
                <Link 
                  to="/register" 
                  className={`ml-4 px-3 py-2 rounded-md text-sm font-medium text-white bg-primary hover:bg-primary-dark`}
                >
                  Inscription
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

