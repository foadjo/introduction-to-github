"""
Routes de gestion des utilisateurs pour l'application
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.main import db
from src.models.user import User
from src.models.loyalty import LoyaltyCard
import uuid

users_bp = Blueprint('users', __name__)

# Fonction utilitaire pour vérifier si l'utilisateur est admin
def is_admin(user_id):
    """Vérifier si l'utilisateur est un administrateur"""
    user = User.query.get(user_id)
    return user and user.role == 'admin'


@users_bp.route('', methods=['GET'])
@jwt_required()
def get_users():
    """Récupérer tous les utilisateurs (admin uniquement)"""
    user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    # Paramètres de filtrage optionnels
    role = request.args.get('role')
    
    # Construire la requête
    query = User.query
    
    if role:
        query = query.filter_by(role=role)
    
    # Exécuter la requête
    users = query.all()
    
    # Préparer la réponse avec les informations de carte de fidélité
    result = []
    for user in users:
        user_data = user.to_dict()
        
        # Ajouter les informations de carte de fidélité si disponible
        if user.loyalty_card:
            user_data['loyalty_card'] = user.loyalty_card.to_dict()
        
        result.append(user_data)
    
    return jsonify(result), 200


@users_bp.route('/<int:user_id>', methods=['GET'])
@jwt_required()
def get_user(user_id):
    """Récupérer un utilisateur par son ID (admin ou l'utilisateur lui-même)"""
    current_user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin ou s'il s'agit de son propre profil
    if not is_admin(current_user_id) and current_user_id != user_id:
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    # Préparer la réponse avec les informations de carte de fidélité
    user_data = user.to_dict()
    
    # Ajouter les informations de carte de fidélité si disponible
    if user.loyalty_card:
        user_data['loyalty_card'] = user.loyalty_card.to_dict()
    
    return jsonify(user_data), 200


@users_bp.route('/<int:user_id>', methods=['PUT'])
@jwt_required()
def update_user(user_id):
    """Mettre à jour un utilisateur (admin uniquement)"""
    current_user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(current_user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    data = request.get_json()
    
    # Mettre à jour les champs de l'utilisateur
    if 'first_name' in data:
        user.first_name = data['first_name']
    if 'last_name' in data:
        user.last_name = data['last_name']
    if 'email' in data:
        # Vérifier si l'email est déjà utilisé par un autre utilisateur
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user and existing_user.id != user_id:
            return jsonify({'message': 'Cet email est déjà utilisé'}), 400
        user.email = data['email']
    if 'phone' in data:
        user.phone = data['phone']
    if 'role' in data:
        user.role = data['role']
    if 'is_active' in data:
        user.is_active = data['is_active']
    if 'password' in data and data['password']:
        user.set_password(data['password'])
    
    db.session.commit()
    
    return jsonify({'message': 'Utilisateur mis à jour avec succès'}), 200


@users_bp.route('/<int:user_id>/loyalty-card', methods=['POST'])
@jwt_required()
def create_loyalty_card(user_id):
    """Créer une carte de fidélité pour un utilisateur (admin uniquement)"""
    current_user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(current_user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    # Vérifier si l'utilisateur a déjà une carte de fidélité
    if user.loyalty_card:
        return jsonify({'message': 'Cet utilisateur a déjà une carte de fidélité'}), 400
    
    # Créer une nouvelle carte de fidélité
    card_number = f"SNACK{user.id:05d}"
    qr_code = f"SNACK-{user.id}-{uuid.uuid4().hex[:8]}"
    
    loyalty_card = LoyaltyCard(
        user_id=user.id,
        card_number=card_number,
        qr_code=qr_code,
        points=0
    )
    
    db.session.add(loyalty_card)
    db.session.commit()
    
    return jsonify(loyalty_card.to_dict()), 201


@users_bp.route('/<int:user_id>/loyalty-card', methods=['PUT'])
@jwt_required()
def update_loyalty_card(user_id):
    """Mettre à jour les points de fidélité d'un utilisateur (admin uniquement)"""
    current_user_id = get_jwt_identity()
    
    # Vérifier si l'utilisateur est admin
    if not is_admin(current_user_id):
        return jsonify({'message': 'Accès non autorisé'}), 403
    
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'message': 'Utilisateur non trouvé'}), 404
    
    # Vérifier si l'utilisateur a une carte de fidélité
    if not user.loyalty_card:
        return jsonify({'message': 'Cet utilisateur n\'a pas de carte de fidélité'}), 404
    
    data = request.get_json()
    
    # Mettre à jour les points de fidélité
    if 'points' in data:
        user.loyalty_card.points = data['points']
    
    db.session.commit()
    
    return jsonify(user.loyalty_card.to_dict()), 200

