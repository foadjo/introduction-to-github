import { useState, useEffect, useRef } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { useMutation } from '@tanstack/react-query';
import { loyaltyService } from '../../services/api';

const Scanner = () => {
  const [scanning, setScanning] = useState(false);
  const [scannedResult, setScannedResult] = useState(null);
  const [error, setError] = useState('');
  const [amount, setAmount] = useState('');
  const [customerInfo, setCustomerInfo] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const scannerRef = useRef(null);
  const scannerContainerRef = useRef(null);

  // Mutation pour envoyer les données du scan
  const scanMutation = useMutation({
    mutationFn: loyaltyService.scanQrCode,
    onSuccess: (data) => {
      setCustomerInfo(data);
      setError('');
      
      // Ajouter la transaction à l'historique
      const newTransaction = {
        id: Date.now(),
        customer_name: data.customer_name,
        amount: parseFloat(amount),
        points_earned: data.points_earned,
        date: new Date().toISOString()
      };
      
      setTransactions(prev => [newTransaction, ...prev].slice(0, 10));
    },
    onError: (err) => {
      setError(err.response?.data?.message || 'Erreur lors du scan. Veuillez réessayer.');
      setCustomerInfo(null);
    }
  });

  // Initialiser le scanner
  useEffect(() => {
    if (!scannerContainerRef.current) return;

    scannerRef.current = new Html5Qrcode('admin-scanner');

    return () => {
      if (scannerRef.current && scanning) {
        scannerRef.current.stop().catch(err => console.error('Erreur lors de l\'arrêt du scanner:', err));
      }
    };
  }, []);

  // Démarrer le scanner
  const startScanner = () => {
    if (!scannerRef.current) return;

    setScanning(true);
    setScannedResult(null);
    setError('');
    setCustomerInfo(null);

    const config = {
      fps: 10,
      qrbox: { width: 250, height: 250 },
      aspectRatio: 1.0
    };

    scannerRef.current.start(
      { facingMode: 'environment' },
      config,
      onScanSuccess,
      onScanFailure
    ).catch(err => {
      setError('Erreur lors du démarrage du scanner: ' + err.message);
      setScanning(false);
    });
  };

  // Arrêter le scanner
  const stopScanner = () => {
    if (scannerRef.current && scanning) {
      scannerRef.current.stop().then(() => {
        setScanning(false);
      }).catch(err => {
        console.error('Erreur lors de l\'arrêt du scanner:', err);
        setScanning(false);
      });
    }
  };

  // Gérer le succès du scan
  const onScanSuccess = (decodedText) => {
    setScannedResult(decodedText);
    stopScanner();
  };

  // Gérer l'échec du scan
  const onScanFailure = (error) => {
    // On ne fait rien ici pour éviter de spammer les erreurs
    console.log('Erreur de scan (ignorée):', error);
  };

  // Valider le scan
  const handleValidateScan = () => {
    if (!scannedResult || !amount) {
      setError('Veuillez scanner un QR code et entrer un montant');
      return;
    }

    const amountValue = parseFloat(amount);
    if (isNaN(amountValue) || amountValue <= 0) {
      setError('Veuillez entrer un montant valide');
      return;
    }

    // Envoyer les données au serveur
    scanMutation.mutate({
      qr_code: scannedResult,
      amount: amountValue
    });
  };

  // Réinitialiser le scanner
  const handleReset = () => {
    setScannedResult(null);
    setError('');
    setAmount('');
    setCustomerInfo(null);
    startScanner();
  };

  // Formater la date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Section de scan */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Scanner QR Code</h3>
        
        <div 
          id="admin-scanner" 
          ref={scannerContainerRef}
          className="w-full h-64 bg-gray-100 rounded-lg overflow-hidden mb-4"
        ></div>

        <div className="flex justify-center mt-4 mb-6">
          {!scanning ? (
            <button
              onClick={startScanner}
              className="bg-orange-600 text-white px-6 py-2 rounded-md font-medium hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              Démarrer le scanner
            </button>
          ) : (
            <button
              onClick={stopScanner}
              className="bg-gray-600 text-white px-6 py-2 rounded-md font-medium hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            >
              Arrêter le scanner
            </button>
          )}
        </div>

        {/* Résultat du scan */}
        {scannedResult && (
          <div className="border-t pt-4">
            <h4 className="text-md font-semibold text-gray-900 mb-2">QR Code scanné</h4>
            <div className="bg-gray-50 p-3 rounded-lg mb-4">
              <p className="text-gray-700 break-all">{scannedResult}</p>
            </div>

            <div className="mb-4">
              <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
                Montant de l'achat (€)
              </label>
              <input
                type="number"
                id="amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="0.00"
                step="0.01"
                min="0"
              />
            </div>
            
            <div className="flex space-x-4">
              <button
                onClick={handleValidateScan}
                disabled={scanMutation.isPending}
                className="flex-1 bg-green-600 text-white px-4 py-2 rounded-md font-medium hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-green-300"
              >
                {scanMutation.isPending ? 'Validation...' : 'Valider l\'achat'}
              </button>
              <button
                onClick={handleReset}
                className="flex-1 bg-gray-500 text-white px-4 py-2 rounded-md font-medium hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              >
                Réinitialiser
              </button>
            </div>
          </div>
        )}

        {/* Affichage des erreurs */}
        {error && (
          <div className="mt-4 p-3 bg-red-50 border-l-4 border-red-500">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {/* Informations client (après validation) */}
        {customerInfo && (
          <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
            <h4 className="text-md font-semibold text-gray-900 mb-2">Transaction réussie</h4>
            <div className="space-y-2">
              <p className="text-gray-700">
                <span className="font-medium">Client :</span> {customerInfo.customer_name}
              </p>
              <p className="text-gray-700">
                <span className="font-medium">Points gagnés :</span> <span className="text-green-600">+{customerInfo.points_earned}</span>
              </p>
              <p className="text-gray-700">
                <span className="font-medium">Total des points :</span> {customerInfo.total_points}
              </p>
              <p className="text-gray-700">
                <span className="font-medium">Date :</span> {formatDate(new Date().toISOString())}
              </p>
            </div>
            <button
              onClick={handleReset}
              className="mt-4 w-full bg-orange-600 text-white px-4 py-2 rounded-md font-medium hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              Scanner un autre code
            </button>
          </div>
        )}
      </div>

      {/* Section d'historique */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Historique des transactions récentes</h3>
        
        {transactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Client
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Montant
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Points
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {transactions.map((transaction) => (
                  <tr key={transaction.id}>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(transaction.date)}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {transaction.customer_name}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {transaction.amount.toFixed(2)} €
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-green-600">
                      +{transaction.points_earned}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p>Aucune transaction récente</p>
            <p className="text-sm mt-2">Les transactions apparaîtront ici après validation</p>
          </div>
        )}

        {/* Saisie manuelle */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h4 className="text-md font-semibold text-gray-900 mb-4">Saisie manuelle</h4>
          <p className="text-sm text-gray-600 mb-4">
            Si le scan ne fonctionne pas, vous pouvez saisir manuellement le numéro de carte du client.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="card_number" className="block text-sm font-medium text-gray-700 mb-1">
                Numéro de carte
              </label>
              <input
                type="text"
                id="card_number"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="ex: SNACK12345"
              />
            </div>
            <div>
              <label htmlFor="manual_amount" className="block text-sm font-medium text-gray-700 mb-1">
                Montant (€)
              </label>
              <input
                type="number"
                id="manual_amount"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="0.00"
                step="0.01"
                min="0"
              />
            </div>
          </div>
          
          <button
            className="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-md font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Valider manuellement
          </button>
        </div>
      </div>
    </div>
  );
};

export default Scanner;

