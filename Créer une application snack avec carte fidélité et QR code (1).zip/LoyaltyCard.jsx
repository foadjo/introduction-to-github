import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { QRCodeSVG } from 'qrcode.react';
import { loyaltyService } from '../services/api';

const LoyaltyCard = () => {
  const [showQRCode, setShowQRCode] = useState(false);

  // Récupérer les informations de la carte de fidélité
  const { data, isLoading, isError, error } = useQuery({
    queryKey: ['loyaltyCard'],
    queryFn: loyaltyService.getCard,
    // Données fictives pour le développement
    placeholderData: {
      loyalty_card: {
        card_number: 'SNACK12345',
        qr_code: 'SNACK-1-20250607',
        points: 120
      },
      recent_transactions: [
        {
          id: 1,
          transaction_date: '2025-06-05T14:30:00',
          total_amount: 15.50,
          points_earned: 155
        },
        {
          id: 2,
          transaction_date: '2025-06-01T12:15:00',
          total_amount: 8.50,
          points_earned: 85
        }
      ]
    }
  });

  // Formater la date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  // Télécharger le QR code
  const downloadQRCode = () => {
    const canvas = document.getElementById('qr-code-canvas');
    if (canvas) {
      const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
      const downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = `carte-fidelite-${data?.loyalty_card?.card_number || 'snack'}.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Ma Carte de Fidélité</h1>
          <p className="text-gray-600">
            Présentez votre QR code lors de vos achats pour cumuler des points
          </p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-orange-500 border-r-transparent"></div>
            <p className="mt-4 text-gray-600">Chargement de votre carte de fidélité...</p>
          </div>
        ) : isError ? (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">
                  {error?.message || "Erreur lors du chargement de votre carte de fidélité. Veuillez réessayer."}
                </p>
              </div>
            </div>
          </div>
        ) : data?.loyalty_card ? (
          <div className="space-y-8">
            {/* Carte de fidélité */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 px-6 py-4">
                <h2 className="text-xl font-semibold text-white">Carte de Fidélité</h2>
              </div>
              <div className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="mb-6 md:mb-0">
                    <p className="text-gray-600 text-sm mb-1">Numéro de carte</p>
                    <p className="text-lg font-semibold text-gray-900">{data.loyalty_card.card_number}</p>
                    
                    <div className="mt-6">
                      <p className="text-gray-600 text-sm mb-1">Points accumulés</p>
                      <p className="text-3xl font-bold text-orange-600">{data.loyalty_card.points}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-center">
                    {showQRCode ? (
                      <div className="bg-white p-2 border rounded">
                        <QRCodeSVG
                          id="qr-code-canvas"
                          value={data.loyalty_card.qr_code}
                          size={180}
                          bgColor="#FFFFFF"
                          fgColor="#000000"
                          level="H"
                          includeMargin={false}
                        />
                      </div>
                    ) : (
                      <button
                        onClick={() => setShowQRCode(true)}
                        className="bg-orange-600 text-white px-4 py-2 rounded-md hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                      >
                        Afficher mon QR Code
                      </button>
                    )}
                    
                    {showQRCode && (
                      <button
                        onClick={downloadQRCode}
                        className="mt-4 text-orange-600 hover:text-orange-800 text-sm font-medium flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                        </svg>
                        Télécharger
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Historique des transactions */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Historique récent</h2>
              </div>
              
              {data.recent_transactions && data.recent_transactions.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Montant
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Points gagnés
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {data.recent_transactions.map((transaction) => (
                        <tr key={transaction.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatDate(transaction.transaction_date)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {transaction.total_amount.toFixed(2)} €
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-right text-green-600">
                            +{transaction.points_earned}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-6 text-center">
                  <p className="text-gray-600">Aucune transaction récente</p>
                </div>
              )}
            </div>

            {/* Informations sur le programme de fidélité */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Comment ça marche ?</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 h-6 w-6 text-orange-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h3 className="text-md font-medium text-gray-900">Présentez votre QR code</h3>
                      <p className="text-sm text-gray-600">À chaque achat, présentez votre QR code au personnel pour scanner.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="flex-shrink-0 h-6 w-6 text-orange-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h3 className="text-md font-medium text-gray-900">Cumulez des points</h3>
                      <p className="text-sm text-gray-600">Gagnez 10 points pour chaque euro dépensé dans notre snack.</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="flex-shrink-0 h-6 w-6 text-orange-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h3 className="text-md font-medium text-gray-900">Échangez vos points</h3>
                      <p className="text-sm text-gray-600">Utilisez vos points pour obtenir des récompenses comme des boissons ou des sandwichs gratuits.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-6 text-center">
            <p className="text-gray-600 mb-4">Vous n'avez pas encore de carte de fidélité.</p>
            <button
              className="bg-orange-600 text-white px-4 py-2 rounded-md hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              Créer ma carte de fidélité
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoyaltyCard;

