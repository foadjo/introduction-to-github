"""
Script pour initialiser la base de données avec des données de test
"""

from src.main import create_app, db
from src.models.user import User
from src.models.product import Product
from src.models.loyalty import LoyaltyCard
from src.models.reward import Reward
from src.models.system import SystemSetting
import uuid

def init_database():
    """Initialiser la base de données avec des données de test"""
    
    app = create_app()
    
    with app.app_context():
        # Supprimer toutes les tables existantes et les recréer
        db.drop_all()
        db.create_all()
        
        # Créer les paramètres système
        SystemSetting.set_value('points_per_euro', '10', 'Nombre de points attribués par euro dépensé')
        
        # Créer un utilisateur admin
        admin = User(
            first_name='Admin',
            last_name='User',
            email='admin@snackfood.com',
            role='admin'
        )
        admin.set_password('admin123')
        db.session.add(admin)
        
        # Créer des utilisateurs clients de test
        clients = [
            {
                'first_name': 'Jean',
                'last_name': 'Dupont',
                'email': 'jean.dupont@example.com',
                'phone': '0612345678'
            },
            {
                'first_name': 'Marie',
                'last_name': 'Martin',
                'email': 'marie.martin@example.com',
                'phone': '0687654321'
            },
            {
                'first_name': 'Pierre',
                'last_name': 'Durand',
                'email': 'pierre.durand@example.com',
                'phone': '0698765432'
            }
        ]
        
        for client_data in clients:
            client = User(
                first_name=client_data['first_name'],
                last_name=client_data['last_name'],
                email=client_data['email'],
                phone=client_data['phone'],
                role='client'
            )
            client.set_password('password123')
            db.session.add(client)
        
        db.session.commit()
        
        # Créer des cartes de fidélité pour les clients
        clients_in_db = User.query.filter_by(role='client').all()
        for client in clients_in_db:
            card_number = f"SNACK{client.id:05d}"
            qr_code = f"SNACK-{client.id}-{uuid.uuid4().hex[:8]}"
            
            loyalty_card = LoyaltyCard(
                user_id=client.id,
                card_number=card_number,
                qr_code=qr_code,
                points=50 + (client.id * 30)  # Points de test
            )
            db.session.add(loyalty_card)
        
        # Créer des produits de test
        products = [
            {
                'name': 'Sandwich Poulet',
                'description': 'Poulet grillé, salade, tomate, sauce maison',
                'price': 5.50,
                'category': 'sandwich',
                'image_url': 'https://via.placeholder.com/300x200?text=Sandwich+Poulet'
            },
            {
                'name': 'Sandwich Thon',
                'description': 'Thon, maïs, salade, œuf, mayonnaise',
                'price': 5.00,
                'category': 'sandwich',
                'image_url': 'https://via.placeholder.com/300x200?text=Sandwich+Thon'
            },
            {
                'name': 'Panini 3 Fromages',
                'description': 'Mozzarella, chèvre, emmental, tomate, origan',
                'price': 6.00,
                'category': 'panini',
                'image_url': 'https://via.placeholder.com/300x200?text=Panini+Fromage'
            },
            {
                'name': 'Salade César',
                'description': 'Salade verte, poulet, parmesan, croûtons, sauce césar',
                'price': 7.50,
                'category': 'salade',
                'image_url': 'https://via.placeholder.com/300x200?text=Salade+César'
            },
            {
                'name': 'Coca-Cola',
                'description': 'Canette 33cl',
                'price': 1.50,
                'category': 'boisson',
                'image_url': 'https://via.placeholder.com/300x200?text=Coca-Cola'
            },
            {
                'name': 'Eau minérale',
                'description': 'Bouteille 50cl',
                'price': 1.00,
                'category': 'boisson',
                'image_url': 'https://via.placeholder.com/300x200?text=Eau+minérale'
            },
            {
                'name': 'Brownie',
                'description': 'Brownie au chocolat fait maison',
                'price': 3.00,
                'category': 'dessert',
                'image_url': 'https://via.placeholder.com/300x200?text=Brownie'
            },
            {
                'name': 'Menu Sandwich',
                'description': 'Sandwich au choix + boisson + dessert',
                'price': 9.50,
                'category': 'menu',
                'image_url': 'https://via.placeholder.com/300x200?text=Menu+Sandwich'
            }
        ]
        
        for product_data in products:
            product = Product(
                name=product_data['name'],
                description=product_data['description'],
                price=product_data['price'],
                category=product_data['category'],
                image_url=product_data['image_url']
            )
            db.session.add(product)
        
        # Créer des récompenses de test
        rewards = [
            {
                'name': 'Boisson gratuite',
                'description': 'Une boisson au choix offerte',
                'points_required': 100
            },
            {
                'name': 'Sandwich gratuit',
                'description': 'Un sandwich au choix offert',
                'points_required': 200
            },
            {
                'name': 'Menu complet',
                'description': 'Un menu complet offert (sandwich + boisson + dessert)',
                'points_required': 500
            },
            {
                'name': 'Réduction de 10%',
                'description': 'Une réduction de 10% sur votre prochain achat',
                'points_required': 150
            },
            {
                'name': 'Dessert gratuit',
                'description': 'Un dessert au choix offert',
                'points_required': 80
            }
        ]
        
        for reward_data in rewards:
            reward = Reward(
                name=reward_data['name'],
                description=reward_data['description'],
                points_required=reward_data['points_required']
            )
            db.session.add(reward)
        
        db.session.commit()
        
        print("Base de données initialisée avec succès !")
        print("Utilisateurs créés :")
        print("- Admin: admin@snackfood.com / admin123")
        print("- Client 1: jean.dupont@example.com / password123")
        print("- Client 2: marie.martin@example.com / password123")
        print("- Client 3: pierre.durand@example.com / password123")

if __name__ == '__main__':
    init_database()

